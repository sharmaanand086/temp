   <?php
 session_start();
  
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');   
   $coachid = $_GET['cid'];   
   $clientid= $_GET['id'];
  $sql="SELECT DISTINCT * FROM `interclient_registrations` where coach_id='$coachid' AND id='$clientid'";
  $rs = mysqli_query($conn,$sql);       
                 
  $row = $rs->fetch_assoc(); 
             
   ?>

          <!--------------------
          start - main content
          -------------------->
<div class="content-i">
            <div class="content-box"><div class="row">
  <div class="col-sm-5">
    <div class="user-profile compact">
      <div class="up-head-w" style="background-image:url(img/profile_bg1.jpg)">
        <div class="up-social">
          <a href="#"><i class="os-icon os-icon-twitter"></i></a><a href="#"><i class="os-icon os-icon-facebook"></i></a>
        </div>
        <div class="up-main-info">
          <h2 class="up-header">
            <?php echo $row['name']; ?>
          </h2>
          <h6 class="up-sub-header">
            <!-- Product Designer at Facebook -->
          </h6>
        </div>
        <svg class="decor" width="842px" height="219px" viewBox="0 0 842 219" preserveAspectRatio="xMaxYMax meet" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g transform="translate(-381.000000, -362.000000)" fill="#FFFFFF"><path class="decor-path" d="M1223,362 L1223,581 L381,581 C868.912802,575.666667 1149.57947,502.666667 1223,362 Z"></path></g></svg>
      </div>
      <div class="up-controls">
        <div class="row">
          <div class="col-sm-6">
            <div class="value-pair">
              <div class="label">
                Status:
              </div>
              <div class="value badge badge-pill badge-success">
                Online
              </div>
            </div>
          </div>
          <div class="col-sm-6 text-right">
            <a class="btn btn-primary btn-sm" href=""><i class="os-icon os-icon-link-3"></i><span>  <form action="zip.php" method="post" >
                <?php $pdfname =  $row['pdf'];
                $urlfile = explode(",", $pdfname);
               // print_r($urlfile);
                foreach ($urlfile as  $value) {
                    if($value ==''){

                    }else{
                    $trimval = trim($value);
                ?>
        <input type="hidden" class="mycheckbox" name="files[]" value="pdffile/<?php echo $trimval; ?>"/>
                <?php
              }
                }
                ?>               
                <input type="submit" value="Download" style="background: transparent;    border: none;color: white;" />
                </form></span></a>
          </div>
        </div>
      </div>
      <div class="up-contents">
        <div class="m-b">
          <div class="row m-b">            
          </div>
          <div class="padded">
            <?php 
                  $c_email=  $row['email'];
                  $c_phone = $row['phone'];
                  $maxqry = "SELECT DISTINCT cat_marks FROM `results_userinfos` where `email`='$c_email' AND mobile='$c_phone'";
                  $maxcat = mysqli_query($conn,$maxqry); 
                  $catrow = $maxcat ->fetch_array(MYSQLI_ASSOC);
              //var_dump($catrow);
              foreach ($catrow as  $maxcatvalue) {
                   $maxv = explode(",",$maxcatvalue);
                   //var_dump($maxv);
                   $categories = '';
             foreach ($maxv as  $value_m) { 
              if( $value_m !=''){
                $value_t = explode(":", $value_m);
              //  var_dump( $value_t);
              ?>
                <div class="os-progress-bar primary">
              <div class="bar-labels">
                <div class="bar-label-left">
                  <span><?php echo $value_t[1]; ?></span><span class="positive"><?php echo $value_t[2]; ?></span>
                </div>
                <div class="bar-label-right">
                  <span class="info"><?php echo $value_t[2]; ?>/150</span>
                </div>
              </div>
              <?php
                $percent =  $value_t[2]/150*100;  
                 $style_t1 = 'width: ' . $percent . '%;';              
              ?>
              <div class="bar-level-1" style="width: 100%">
                <div class="bar-level-2" style="width: 100%">
            <div class="bar-level-3" style="<?php echo $style_t1; ?>"></div>
                </div>
              </div>
            </div>         
               
          <?php } } }   ?> 
          </div>
        </div>
      </div>
    </div>
    <div class="element-wrapper">
      <div class="element-box">
        <h6 class="element-header">
          User Activity
        </h6>
        <div class="timed-activities compact">
           <?php 
                  $c_email=  $row['email'];
                  $c_phone = $row['phone'];
                 $qforactity = "SELECT * FROM `recentactivity` where `email`='$c_email' AND phone='$c_phone'";
                  $Activity = mysqli_query($conn,$qforactity); 
                  while($actrow = $Activity ->fetch_assoc()){            
                      //var_dump($actrow);
                ?>
          <div class="timed-activity">
            <div class="ta-date">
              <span><?php $d_time= $actrow['updatedat'];
              $date = explode(",",  $d_time);
               
               ?><?php echo $date[0]; ?></span>
            </div>
            <div class="ta-record-w">
              <div class="ta-record">
                <div class="ta-timestamp">
                  <strong><?php echo $date[1]; ?></strong> 
                </div>
                <div class="ta-activity">
                  <?php echo $actrow['activity_description']; ?>
                </div>
              </div>
             
            </div>
          </div>
<?php } ?>
      
        
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-7">
    <div class="element-wrapper">
      <div class="element-box">
       
          <div class="element-info">
            <div class="element-info-with-icon">
              <div class="element-info-icon">
                <div class="os-icon os-icon-wallet-loaded"></div>
              </div>
              <div class="element-info-text">
                <h5 class="element-inner-header">
                  Profile Settings
                </h5>
                 <?php 
                              if(isset($_GET['msg'])){
                            ?> <div class="alert alert-success"> <?php echo $_GET['msg']; ?></div> 
                          <?php } ?>
                          <?php 
                              if(isset($_GET['msg1'])){
                            ?> <div class="alert alert-danger"> <?php echo $_GET['msg1']; ?></div> 
                          <?php } ?>
                <div class="element-inner-desc">
                  Validation of the form is made possible using powerful validator plugin for bootstrap. <a href="http://1000hz.github.io/bootstrap-validator/" target="_blank">Learn more about Bootstrap Validator</a>
                </div>
              </div>
            </div>
          </div>
        <form name="formcomment" action="commentinsert.php" method="POST">
          <div class="row">
            <div class="col-sm-12">
            <div class="form-group">
            <label for=""> Email address</label>             
            <input class="form-control" id="email" name="email" value="<?php echo  $row['email']; ?>" readonly='true'  >             
            </div>              
            </div>
            <div class="col-sm-6">
            <div class="form-group">
                <label for=""> Name</label><input class="form-control"   placeholder="Password"  id="name" name="name" type="text" value="<?php echo  $row['name']; ?>" readonly='true'  >
                 
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label for="">Phone</label><input class="form-control"  id="phone" value="<?php echo  $row['phone']; ?>" name="phone" type="text"readonly='true'  >
                <div class="help-block form-text with-errors form-control-feedback"></div>
              </div>
            </div>
          </div>           
        
          <fieldset class="form-group">
            <legend style="color: #ff0000"><span>Section Booked</span></legend>
            <div class="row">
            
              <div class="col-sm-6">
                <div class="form-group">
                  <?php  $date = strtotime($row["session_date"]);
                                $fordate = date("d-m-Y", $date);
                                ?>
                  <label for=""> Date </label><input class="form-control" value="<?php echo  $fordate; ?>"  type="text" disabled="disabled"  >
                  
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="">Time</label><input class="form-control" value="<?php echo  $row['session_time']; ?>"  type="text" disabled="disabled"  >
                 
                </div>
              </div>
            </div>
             <?php
                $clinente = $row['email'];
                $clinetp = $row['phone'];
                    $comtqry = "SELECT  email,phone,yes_no,comment,client_id,coach_id,updatedat FROM `clients_status` where `email`='$clinente' AND phone='$clinetp'";
                  $rescommt = mysqli_query($conn,$comtqry); 
                  $rowcmt2 =  $rescommt->fetch_assoc(); 
                  //var_dump($rowcmt2['yes_no']);
                ?>
            <div class="row">
            <div class="col-sm-12">                
              <div class="form-group row">
                 <label class="col-sm-4 col-form-label">Call</label>
                <div class="col-sm-8">
                  <?php if( $rowcmt2['yes_no'] ==1 ) {?>
                  <div class="form-check">
                    <label class="form-check-label"><input checked class="form-check-input"  id="yes" onClick="UpdateCommentFunction()" name="optionsRadios"  type="radio" value="1">Yes</label>
                  </div>
                  <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input" name="optionsRadios" id="no" onClick="UpdateCommentFunction()" type="radio" value="2">No</label>
                  </div> 
                <?php } if( $rowcmt2['yes_no'] ==2 ) {?>
                  <div class="form-check">
                    <label class="form-check-label"><input checked class="form-check-input" name="optionsRadios" onClick="UpdateCommentFunction()" id="no"  type="radio" value="2">No</label>
                  </div> 
                   <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input"  id="yes" name="optionsRadios" onClick="UpdateCommentFunction()" type="radio" value="1">Yes</label>
                  </div>
                  <?php } if( $rowcmt2['yes_no'] == 3) {?> 
                    <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input"  id="yes" name="optionsRadios" onClick="UpdateCommentFunction()" type="radio" value="1">Yes</label>
                  </div>
                  <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input" name="optionsRadios" id="no" onClick="UpdateCommentFunction()" type="radio" value="2">No</label>
                  </div> 
                  <?php } if( $rowcmt2['yes_no'] == '') { ?> 
                    <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input"  id="yes" name="optionsRadios" onClick="UpdateCommentFunction()" type="radio" value="1">Yes</label>
                  </div>
                  <div class="form-check">
                    <label class="form-check-label"><input  class="form-check-input" name="optionsRadios" id="no" onClick="UpdateCommentFunction()" type="radio" value="2">No</label>
                  </div> 
                  <?php } ?>                
                </div>
              </div>
               
            </div>
               
            </div>
             
            <div class="form-group">
              <label> Comment   </label>               
              <textarea readonly='true' name="commentf_yes_no" class="form-control" id="comment" rows="3"><?php echo  $rowcmt2['comment']; ?> </textarea>
            <input type="hidden" name="coach_id" value="<?php echo $coachid; ?>">
            <input type="hidden" name="client_id" value="<?php echo $clientid; ?>">
            </div>
          </fieldset>           
          <div class="form-buttons-w">
            <button class="btn btn-danger disabled" type="submit" disabled> Submit</button>
          </div>
       <form>

          <fieldset class="form-group" style="display: none;">
            <legend><span>Section FollowUp</span></legend>
            <div class="row">
            
              <div class="col-sm-6">
                  <form action="reminde1.php" method="post">
                    <input  type="hidden"  class="form-control"  name="email" value="<?php echo  $row['email']; ?>" readonly='true'>  

                      <input class="form-control"   placeholder="Password"   name="name" type="hidden" value="<?php echo  $row['name']; ?>" readonly='true'  >
                      <input class="form-control"    value="<?php echo  $row['phone']; ?>" name="phone" type="hidden"readonly='true'  >
                       <input class="form-control"  value="<?php echo  $clientid;  ?>" name="client_id" type="hidden"readonly='true'  >
                        <input class="form-control"    value="<?php echo  $coachid; ?>" name="coach_id" type="hidden"readonly='true'  >
                  <button class="btn btn-primary disabled" type="submit"> Reminder one</button>
                 </form>
                </div>
                <div class="col-sm-6">
                     <form action="reminde2.php" method="post">
                    <input  type="hidden"  class="form-control"   name="email" value="<?php echo  $row['email']; ?>" readonly='true'>  

                      <input class="form-control"   placeholder="Password"  name="name" type="hidden" value="<?php echo  $row['name']; ?>" readonly='true'  >
                      <input class="form-control" value="<?php echo  $row['phone']; ?>" name="phone" type="hidden"readonly='true'  >
                       <input class="form-control"    value="<?php echo  $clientid;  ?>" name="client_id" type="hidden"readonly='true'  >
                        <input class="form-control"   value="<?php echo  $coachid; ?>" name="coach_id" type="hidden"readonly='true'  >
                 <button class="btn btn-primary disabled" type="submit"> Remnider Two</button>
               </form>
          
                </div>
            </div>
          </fieldset>
      </div>
    </div>
  </div>
</div> 
            
</div>            
</div>

          <!--------------------
          END -  - main content
          -------------------->
 
     
     <script >     
  $(".alert-success").show();
setTimeout(function() { $(".alert-success").hide(); }, 3000);
$(".alert-danger").show();
setTimeout(function() { $(".alert-danger").hide(); }, 3000);
</script>

  <?php 
include('footer.php'); 
?>
