 <?php
 session_start();
 
 
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');
$coachid = $_GET['cid'];
  $clientid;
  $sql="SELECT DISTINCT * FROM `interclient_registrations` where coach_id='$coachid'";
  $rs = mysqli_query($conn,$sql);   
  ?>
  
        <!--------------------
          start - main content
          -------------------->
           <div class="content-i">
            <div class="content-box">
              <div class="row pt-4">
                <div class="col-sm-12">
                  <!--START - Grid of tablo statistics-->
                  <div class="element-wrapper">
                    <div class="element-actions">
                      <form class="form-inline justify-content-sm-end">
                        <select class="form-control form-control-sm rounded">
                          <option value="Pending">
                            Today
                          </option>
                          <option value="Active">
                            Last Week 
                          </option>
                          <option value="Cancelled">
                            Last 30 Days
                          </option>
                        </select>
                      </form>
                    </div>
                    <h6 class="element-header">
                      Leads Dasboard    
                     </h6>
                    <div class="element-content">
                      <div class="tablo-with-chart">
                        <div class="row">
                          <div class="col-sm-7 col-xxl-8">
                            <div class="tablos">
                              <div class="row mb-xl-2 mb-xxl-3">
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="leads.php?id=<?php echo$coachid; ?>">
                                    <div class="value">
                                     <?php
                             $ttl_bkg="SELECT DISTINCT email  FROM `intersubmitquestion` where coachid='$coachid'";
                              $rstotalbkg = mysqli_query($conn,$ttl_bkg); 
                              $total_clientsbkg = mysqli_num_rows($rstotalbkg);
                             ?> 
                             <?php echo $total_clientsbkg; ?>
                                    </div>
                                    <div class="label">
                                       Total Leads
                                    </div>
                                    <div class="trending trending-up-basic">
                                      <!-- <span>12%</span><i class="os-icon os-icon-arrow-up2"></i> -->
                                    </div>
                                  </a>
                                </div>
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="bookings.php?id=<?php echo$coachid; ?>">
                                    <div class="value">
                                      <?php
                             $ttl_clt="SELECT  DISTINCT email  FROM `interclient_registrations` where coach_id='$coachid'";
                              $rstotalsale = mysqli_query($conn,$ttl_clt); 
                              $total_clients = mysqli_num_rows($rstotalsale);
                             ?> <?php echo $total_clients; ?>
                                    </div>
                                    <div class="label">
                                       Total Bookings
                                    </div>
                                    <div class="trending trending-down-basic">
                                      <!-- <span>12%</span><i class="os-icon os-icon-arrow-down"></i> -->
                                    </div>
                                  </a>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="Discovery.php?id=<?php echo $coachid; ?>">
                                    <div class="value">
                                     <?php
                             $ttl_dc="SELECT  DISTINCT email FROM `clients_status` where coach_id='$coachid' AND yes_no='1'";
                              $rstotaldc = mysqli_query($conn,$ttl_dc); 
                              $total_clientsdc = mysqli_num_rows($rstotaldc);
                             ?> <?php echo $total_clientsdc; ?>
                                    </div>
                                    <div class="label">
                                    Discovery calls
                                    </div>
                                    <div class="trending trending-up-basic">
                                      <!-- <span>12%</span><i class="os-icon os-icon-arrow-up2"></i> -->
                                    </div>
                                  </a>
                                </div>
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="Pending.php?cid=<?php echo$coachid; ?>">
                                    <div class="value">
                                        <?php
                             $ttl_pc="SELECT  DISTINCT email FROM `clients_status` where coach_id='$coachid' AND yes_no='3'";
                              $rstotalpc = mysqli_query($conn,$ttl_pc); 
                              $total_clientsdpc = mysqli_num_rows($rstotalpc);
                             ?> <?php echo $total_clientsdpc; ?>
                                    </div>
                                    <div class="label">
                                    Pending Calls
                                    </div>
                                    <div class="trending trending-down-basic">
                                      <!-- <span>12%</span><i class="os-icon os-icon-arrow-down"></i> -->
                                    </div>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                           
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--END - Grid of tablo statistics-->
                </div>
              </div>
            
              <div class="row pt-4">
                <div class="col-sm-12">
                  <!--START - Recent Ticket Comments-->
                  <div class="element-wrapper">
                    <h6 class="element-header">
                    Discovery calls
                    </h6>
                       <?php 
                    if(isset($_GET['msg'])){
                  ?> <div class="alert alert-success"> <?php echo $_GET['msg']; ?></div> 
                <?php } ?>
                <?php 
                    if(isset($_GET['msg1'])){
                  ?> <div class="alert alert-danger"> <?php echo $_GET['msg1']; ?></div> 
                <?php } ?>
                    <div class="element-box-tp">
                      <div class="table-responsive">
                        <table class="table table-padded">
                          <thead>
                            <tr>
                              <th>
                                Sr No.
                              </th>
                              <th>
                                Name
                              </th>
                              <th>
                                Email
                              </th>
                                <th>
                                Phone
                              </th>
                              <th>
                                Time Slot
                              </th>                       
                              
                               <th>Yes/No</th>
                               <th>More Details</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
 
             if(mysqli_num_rows($rs)>0){
                 $a = 1;
           while($row = $rs->fetch_assoc()) {
                       $clientid=  $row["id"];  
               ?>
                            <tr>
                              <td class="text-center">
                             <?php echo $a++ ?>
                              </td>
                              <td>
                                <div class="user-with-avatar">
                                  <img alt="" src="img/Author__Placeholder.png"><span> <?php echo $row["name"]; ?></span>
                                </div>
                              </td>
                              <td>
                                <div class="smaller lighter">
                                   <?php echo $row["email"]; ?>
                                </div>
                              </td>
                              <td>
                                   <?php echo $row["phone"]; ?>
                                
                              </td>
                              <td >
                                 <?php 
                                 $date = strtotime($row["session_date"]);
                                $fordate = date("d-m-Y", $date);

                                  $time = $row["session_time"];?>
                                 <span><?php echo $fordate; ?></span><br>
                                 <span class="smaller lighter"><?php echo $time; ?></span>                               
                              </td>
                              <td class="nowrap">
                                <?php 
                              $client_id = $row["id"];
                               $clientquery="SELECT DISTINCT * FROM `clients_status` where client_id='$client_id'";
                                $clients = mysqli_query($conn,$clientquery); 
                                $row2 = $clients->fetch_assoc();                               
                                if($row2['yes_no'] == 1){
                                ?>
                                <span class="status-pill smaller green"></span>
                                <span>Yes</span>
                              <?php } ?>
                              <?php 
                              if($row2['yes_no'] == 2){
                                ?>
                                <span class="status-pill smaller red"></span>
                                <span>No</span>
                              <?php } ?>
                               <?php 
                              if($row2['yes_no'] == 3){
                                ?>
                                <span class="status-pill smaller yellow"></span>
                                <span>Pending</span>
                              <?php } ?>
                              </td>
                              <td class="row-actions">
                                 <div class="balance-link">
                            <a class="btn btn-link btn-underlined" href="contact_details.php?cid=<?php echo$coachid; ?>&id=<?php echo $row["id"]; ?>"><span>View Contact</span><i class="os-icon os-icon-arrow-right4"></i></a>
                          </div>
                              </td>
                            </tr>
                             <?php 
                              }
                            }
                            else
                            {
                           ?>
                           <td >
                           <p>Not Found</p>
                           </td>
                          <?php                      
                            }       
                           ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <!--END - Recent Ticket Comments-->
                </div>
              </div> 

            </div>
          </div>
          <!--------------------
          END -  - main content
          -------------------->        
<?php 
include('footer.php');

?> 
 
 
 