 <?php
 session_start();
 if(isset($_SESSION["username"])) {
 
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');
$coachid;
  $sql="SELECT * FROM `etr` where status='1'  ";
  $rs = mysqli_query($conn,$sql);
  ?>
  
        <!--------------------
          start - main content
          -------------------->
 <div class="content-i">
            <div class="content-box">

            <div class="row pt-4">
                <div class="col-sm-12">
                  <!--START - Grid of tablo statistics-->
                  <div class="element-wrapper">
                    <div class="element-actions">
                      <form class="form-inline justify-content-sm-end">
                        <select class="form-control form-control-sm rounded">
                          <option value="Pending">
                            Today
                          </option>
                          <option value="Active">
                            Last Week 
                          </option>
                          <option value="Cancelled">
                            Last 30 Days
                          </option>
                        </select>
                      </form>
                    </div>
                    <h6 class="element-header">
                      Support Service Dashboard
                    </h6>
                    <div class="element-content">
                      <div class="tablo-with-chart">
                        <div class="row">
                          <div class="col-sm-5 col-xxl-4">
                            <div class="tablos">
                              <div class="row mb-xl-2 mb-xxl-3">
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="ncoachrequests.php">
                                    <div class="value">
                                     <?php
                             $ttl_bkg="SELECT DISTINCT email  FROM `etr` where status='0' OR status='1' OR status='2'";
                              $rstotalbkg = mysqli_query($conn,$ttl_bkg); 
                              $total_clientsbkg = mysqli_num_rows($rstotalbkg);
                             ?> 
                             <?php echo $total_clientsbkg; ?>
                                    </div>
                                    <div class="label">
                                     New ETR Requests
                                    </div>
                                   <!--  <div class="trending trending-up-basic">
                                      <span>12%</span><i class="os-icon os-icon-arrow-up2"></i>
                                    </div> -->
                                  </a>
                                </div>
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="#" id="approveclick">
                                    <div class="value">
                                     <?php
                             $ttl_appr="SELECT DISTINCT email  FROM `etr` where status='1'";
                              $rstotalapr = mysqli_query($conn,$ttl_appr); 
                              $total_clientsapr = mysqli_num_rows($rstotalapr);
                             ?> 
                             <?php echo $total_clientsapr; ?>
                                    </div>
                                    <div class="label">
                                      Approve ETR
                                    </div>
                                   <!--  <div class="trending trending-down-basic">
                                      <span>12%</span><i class="os-icon os-icon-arrow-down"></i>
                                    </div> -->
                                  </a>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="ncoachrequests.php">
                                    <div class="value">
                                      <?php
                             $ttl_pending="SELECT DISTINCT email  FROM `etr` where status='0'";
                              $rstotalpnd = mysqli_query($conn,$ttl_pending); 
                              $total_clientspnd = mysqli_num_rows($rstotalpnd);
                             ?> 
                             <?php echo $total_clientspnd; ?>
                                    </div>
                                    <div class="label">
                                     Pending Request
                                    </div>
                                    <!-- <div class="trending trending-up-basic">
                                      <span>12%</span><i class="os-icon os-icon-arrow-up2"></i>
                                    </div> -->
                                  </a>
                                </div>
                                <div class="col-sm-6">
                                  <a class="element-box el-tablo centered trend-in-corner padded bold-label" href="#"  id="approveclick1">
                                    <div class="value">
                                     <?php
                             $ttl_live="SELECT DISTINCT id_request FROM `live-pause` where status='1'";
                              $rstotallive = mysqli_query($conn,$ttl_live); 
                              $total_clientlive = mysqli_num_rows($rstotallive);
                             ?> 
                             <?php echo $total_clientlive; ?>
                                    </div>
                                    <div class="label">
                                     Live Campaing
                                    </div>
                                    <!-- <div class="trending trending-down-basic">
                                      <span>12%</span><i class="os-icon os-icon-arrow-down"></i>
                                    </div> -->
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-7 col-xxl-8">
                            <!--START - Chart Box-->
                            <div class="element-box pl-xxl-5 pr-xxl-5">
                              <div class="el-tablo bigger highlight bold-label">
                                <div class="value">
                                  <?php
                             $ttl_bkg="SELECT DISTINCT email FROM `etr` where status='0' OR status='1' OR status='2'";
                              $rstotalbkg = mysqli_query($conn,$ttl_bkg); 
                              $total_clientsbkg = mysqli_num_rows($rstotalbkg);
                             ?> 
                             <?php echo $total_clientsbkg; ?>
                                </div>
                                <div class="label">
                                  Unique Visitors
                                </div>
                              </div>
                              <div class="el-chart-w"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
                                <canvas height="172" id="lineChart" width="612" style="display: block; width: 681px; height: 192px;" class="chartjs-render-monitor"></canvas>
                              </div>
                            </div>
                            <!--END - Chart Box-->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--END - Grid of tablo statistics-->
                </div>
              </div>
            
              <div class="row pt-4 approvedetr">
                <div class="col-sm-12">
                  <!--START - Recent Ticket Comments-->
                  <div class="element-wrapper">
                    <h6 class="element-header">
                    Approved Requests
                    </h6>
                       <?php 
                    if(isset($_GET['msg'])){
                  ?> <div class="alert alert-success"> <?php echo $_GET['msg']; ?></div> 
                <?php } ?>
                <?php 
                    if(isset($_GET['msg1'])){
                  ?> <div class="alert alert-danger"> <?php echo $_GET['msg1']; ?></div> 
                <?php } ?>
                    <div class="element-box-tp">
                      <div class="table-responsive">
                        <table class="table table-padded">
                          <thead>
                            <tr>
                            <th>Sr No.</th>
                            <th>Coach Id </th>
                            <th>Name</th>
                            <th> Email</th>
                            <th> Phone</th> 
                            <th>Availability</th>
                            <th>More Details</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php            
                         if(mysqli_num_rows($rs)>0){
                           $a=1;
                       while($row = $rs->fetch_assoc()) {
                           ?>
                            <tr>
                              <td class="text-center">
                             <?php echo $a++ ?>
                              </td>
                              <td>
                                  <?php 
                $email = $row["email"];
               $sql="SELECT * FROM `coaches` where email='$email'  ";
               $rs2 = mysqli_query($conn,$sql);
              if(mysqli_num_rows($rs2)>0){
           while($row2 = $rs2->fetch_assoc()) {
            //var_dump($row2);
            $coachid = $row2["coach_id"];
            ?>
               <?php echo $row2["coach_id"]; ?>
             <?php 
                 }
                 }
                  else
                {
                  ?>
           <td> Something went wrong  </td> 
            <?php }  ?>            

               </td>
                              <td>
                                <div class="user-with-avatar">
                                  <img alt="" src="img/Author__Placeholder.png"><span> <?php echo $row["Name"]; ?></span>
                                </div>
                              </td>
                              <td>
                                <div class="smaller lighter">
                                  <?php echo $row["email"]; ?>
                                </div>
                              </td>
                              <td>
                                  <?php echo $row["Phone"]; ?>
                                
                              </td>
                             
                <td><?php 
                $dr=  $row["daterange"];
                $rep = str_replace("Selected Time slot:" , " ",$dr); 
                $exp = str_replace("Clear " , " ",$rep);
                $date = explode(" Date:",$exp); 
               // print_r($date);
              foreach($date as  $value) {
                    if($value == 0){

                    }else{
                      $rid = $row['id'];
                      $slots = $value;
        $sql3="SELECT * FROM `live-pause` where id_request='$rid' AND datetimeslot='$slots'";
        $rs3 = mysqli_query($conn,$sql3);
        $row3 = $rs3->fetch_assoc();
        $live_pause=  $row3['status'];
        if($live_pause == 1){
          echo"<span style='color:green;font-size:14px;'><b>Date :". $value."<b></span>";echo"<br>";echo"<br>";

        }else{
            echo"<span style='color:orange;font-size:14px;'><b>Date :". $value."<b>";echo"<br>";echo"<br></span>";
        }
                 
          }
              }
             // print_r($date[1] );

                ?></td>
                 
                              
                              <td class="row-actions">
                                 <div class="balance-link">
                            <a class="btn btn-link btn-underlined" href="requestdetails.php?id=<?php echo $row["id"]; ?>&cid=<?php echo  $coachid; ?>"><span> More..</span><i class="os-icon os-icon-arrow-right4"></i></a>
                          </div>
                              </td>
                            </tr>
                             <?php 
                              }
                            }
                            else
                            {
                           ?>
                           <td >
                           <p>Not Found</p>
                           </td>
                          <?php                      
                            }       
                           ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <!--END - Recent Ticket Comments-->
                </div>
              </div> 

            </div>
          </div>

          <!--------------------
          END -  - main content
          -------------------->   
          <script >
            $("#approveclick").click(function() {
          $('html,body').animate({
        scrollTop: $(".approvedetr").offset().top},
        'slow');
});
            $("#approveclick1").click(function() {
          $('html,body').animate({
        scrollTop: $(".approvedetr").offset().top},
        'slow');
});
          </script>     
<?php 
include('footer.php'); 
?>
<?php
 }else{
  header("Location:index.php");
 }
 
 