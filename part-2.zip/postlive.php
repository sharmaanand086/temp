<?php 

session_start();
include('connection.php');
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   

$requestid  = $_POST['id'] ;
$datetime  = $_POST['datetime'] ; 
$status = '1';

$query = "SELECT * FROM `live-pause` WHERE `datetimeslot`='$datetime'  AND status='2' AND id_request = '$requestid'";
 $result = mysqli_query($conn,$query); 

 if(mysqli_num_rows($result) == 1){
   $sql1="UPDATE `live-pause` SET `status`='$status'  WHERE `datetimeslot`='$datetime' AND id_request = '$requestid'";   
   $update = mysqli_query($conn,$sql1);     

    if($update == TRUE)
                     {
                      echo "1";
                         
                      }else{
                      
                         echo "0";  
                      }
 }else{
  $insert="INSERT INTO `live-pause`(`status`, `datetimeslot`, `id_request`) VALUES('$status','$datetime ','$requestid')";   
   $insertresult = mysqli_query($conn,$insert);  
  
                    if($insertresult == TRUE)
                     {
                      echo "1";
                         
                      }else{
                      
                         echo "0";  
                      }
                      

 }



   
                   