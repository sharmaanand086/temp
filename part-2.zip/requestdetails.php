 <?php
 session_start();
 if(isset($_SESSION["username"])) {
 
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');
$coach_id = $_GET['cid'];
  $sql="SELECT * FROM `etr` where status='1' AND id='$coach_id'";
  $rs = mysqli_query($conn,$sql);
  ?>
  
        <!--------------------
          start - main content
          -------------------->
          <div class="content-i">
            <div class="content-box">
              
               
              <div class="row pt-4">
                <div class="col-sm-12">
                  <!--START - Recent Ticket Comments-->
                  <div class="element-wrapper">
                    <h6 class="element-header">
                     Requester details
                    </h6>
                    <div class="element-box-tp">
                      <div class="table-responsive">
                        <table class="table table-padded">
                          <thead>
                            <tr>                          
                              
                              <th>
                                Name
                              </th>                              
                              <th>
                               Age limit
                              </th>
                              <th>
                                City
                              </th>
                              <th>
                                Availability
                              </th>
                              <th>ETR</th>
                              <th>Photo</th>                              
                            </tr>
                          </thead>
                          <tbody>
                            <?php 

       
           $id_request =$_GET['id'];      

             if(mysqli_num_rows($rs)>0){
                 $a = 1;
           while($row = $rs->fetch_assoc()) {?>
                            <tr>                              
                              <td>
                                
                                <div class="user-with-avatar">
                                  <a href="viewleads.php?cid=<?php echo $coach_id;?>"><img alt="" src="img/Author__Placeholder.png"><span> <?php echo $row['Name']; ?></span>
                                  </a>
                                </div>
                              
                              </td>
                               
                              <td>
                                 <?php echo $row['Age']; ?>
                              </td>
                              <td class="text-center">
                                <?php echo $row['City']; ?>
                              </td>
                              <td>
                                <?php 
                                  $dr=  $row["daterange"];

                                  $rep = str_replace("Selected Time slot:" , " ",$dr); 
                                  $exp = str_replace("Clear " , " ",$rep);
                                  $date = explode(" Date:",$exp); 
                                    $a = 1;
                                      foreach($date as  $value) {
                                      if($value == 0){

                                      }else{ 
                                        //var_dump($value);
                                      $sql3="SELECT * FROM `live-pause`where datetimeslot='$value'";
                                      $rs3 = mysqli_query($conn,$sql3); 
                                      if(mysqli_num_rows($rs3) > 0){  
                                        ?>
                                      <span style="display: inline-flex;" id = "solTitle<?php echo $a++; ?>">Date: <?php echo $value; ?><br>
                                    <a onClick="clickpause(this.id);" id="<?php echo $value; ?>"><button type="button" class="btn btn-danger">Pause</button>
                                    </a>
                                    <a onClick="clicklive(this.id);" id=""  class="clickpause" style="display:none" ><button type="button" class="btn btn-success" id="<?php echo $value; ?>">Live</button></a>
                                   </span>
                                          <?php
                                          }
                                        if(mysqli_num_rows($rs3) ==0){ 
                                          ?>
                                          <span style="display: inline-flex;"  id = "solTitle<?php echo $a++; ?> ">Date: <?php echo $value; ?> <br>
                                          <a onClick="clickpause(this.id);"  class="clicklive" style="display:none" id="<?php echo $value; ?>" ><button type="button" class="btn btn-danger">Pause</button></a>
                                          <a onClick="clicklive(this.id);" id="<?php echo $value; ?>"  class="clickpause"><button type="button" class="btn btn-success" >Live</button></a></span>
                                        <?php
                                          }  } }          
                                        ?>
                                 
                              </td>
                              <td class="nowrap">
                               <?php    echo"Your_Profession :";
                                        echo $row['yourp'];echo"<br>";
                                        echo "Your_Background: ";
                                        echo $row['yourb'];echo"<br>";
                                        echo "What_is_Your_Mission:";
                                        echo $row['yourm']; ?>
                              </td>
                              <td><?php $uploaded_files = $row['uploaded_files'];
                                    $photo = explode(",", $uploaded_files);
                                    foreach ($photo as $value) {                                     
                                     ?>
                                     <a href=" http://arfeenkhan.net/coach-checklist/uploaded_files/<?php echo $value;?>" download>
                                    <img src=" http://arfeenkhan.net/coach-checklist/uploaded_files/<?php echo $value;?>" alt="etrimages" width="50" height="50" style="border-radius: 50%;">
                                  </a>
                                   <?php
                                    }

                               ?></td>  
                            </tr>

                       <?php  } } 
                           else
                           {
                           ?>
                          <td>
                           <p>Not Found</p>
                           </td>
                         <?php                     
                         }   
                          ?>
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <!--END - Recent Ticket Comments-->
                </div>
              </div> 
            </div>
          </div>

          <!--------------------
          END -  - main content
          -------------------->
           <script >
     function clicklive(id) {
      var datetime = id;   
      var id = <?php echo $_GET['id']; ?>;     
       $.ajax({
            type: "POST",
                url: "postlive.php",
                data: {datetime:datetime,id:id},
        success: function (data)
        {
          console.log(data);
          $('#'+id).css('display','none');
         location.reload();
        },
        error: function ()
        {
            console.log("error");
        }
     });
     }
      function clickpause(id) {
    var datetime = id;  
    var id = <?php echo $_GET['id']; ?>;    
       $.ajax({
            type: "POST",
                url: "postpause.php",
                data: {datetime:datetime,id:id},
        success: function (data)
        {
          console.log(data);          
         location.reload();
        },
        error: function ()
        {
            console.log("error");
        }
     });
     }

  </script>        
<?php 
include('footer.php'); 
?>
<?php
 }else{
  header("Location:index.php");
 }
 
 