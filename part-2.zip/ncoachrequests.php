 <?php 
 session_start();
 $username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');
 $sql="SELECT * FROM `etr` where status='0' OR status='2'";
  $rs = mysqli_query($conn,$sql);

?>
  
         <!--------------------
          start - main content
          -------------------->
 <div class="content-i">
            <div class="content-box">
              
              <div class="row pt-4">
                <div class="col-sm-12">
                  <!--START - Recent Ticket Comments-->
                  <div class="element-wrapper">
                    <h6 class="element-header">
                    New ETR Requests
                    </h6>
                       <?php 
                    if(isset($_GET['msg'])){
                  ?> <div class="alert alert-success"> <?php echo $_GET['msg']; ?></div> 
                <?php } ?>
                <?php 
                    if(isset($_GET['msg1'])){
                  ?> <div class="alert alert-danger"> <?php echo $_GET['msg1']; ?></div> 
                <?php } ?>
                    <div class="element-box-tp">
                      <div class="table-responsive">
                        <table class="table table-padded">
                          <thead>
                            <tr>
                             <th>Sr no.</th>
			                <th>Name</th>
			                <th>Email</th>
			                <th>Phone</th>
			                <th>Age </th>
			                <th>City</th>
			                <th>Availability</th>
			                <th>RTR</th>			                
			                <th>Approval</th>                            
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
 
             if(mysqli_num_rows($rs)>0){
                 $a = 1;
           while($row = $rs->fetch_assoc()) {
               ?>
                            <tr>
                              <td class="text-center">
                             <?php echo $a++ ?>
                              </td>
                              <td>
                                <div class="user-with-avatar">
                                  <img alt="" src="img/Author__Placeholder.png"><span><?php echo $row["Name"]; ?></span>
                                </div>
                              </td>
                              <td>
                                <div class="smaller lighter">
                                   <?php echo $row["email"]; ?>
                                </div>
                              </td>
                              <td>
                                   <?php echo $row["Phone"]; ?>
                                
                              </td>
                              <td><?php echo $row["Age"]; ?></td>
                              <td><?php echo $row["City"]; ?></td>
                             <td><?php 
                $dr=  $row["daterange"];
                $rep = str_replace("Selected Time slot:" , " ",$dr); 
                $exp = str_replace("Clear " , " ",$rep);
                $date = explode(" Date:",$exp); 
               // print_r($date);
              foreach($date as  $value) {
                    if($value == 0){

                    }else{

                   echo"<b>Date :". $value."<b>";echo"<br>";echo"<br>";
                 }
              }
             // print_r($date[1] );

                ?></td>
                <td  ><?php echo"YOUR PROFESSION :-"; echo $row["yourp"]; echo"<br>";
                echo"YOUR BACKGROUND:-"; echo $row["yourb"]; echo"<br>";
                echo"WHAT IS YOUR MISSIO:-"; echo $row["yourm"]; echo"<br>"; ?></td>
                
                 <td>
                  <?php if($row["status"] == 0){
                      ?>
                      <a class="badge badge-success-inverted" href="approverequest.php?id=<?php echo $row['id']; ?>">Approve</a>                  
                      <a class="badge badge-danger-inverted" href="rejectrequest.php?id=<?php echo $row['id']; ?>">Rejecte</a>                
                    </a>
                  <?php } ?>

                     <?php if($row["status"] == 1){
                      ?><a class="badge badge-success-inverted" href="">Approved</a>
                        <?php
                        } ?>
                     <?php if($row["status"] == 2){
                      ?><a class="badge badge-danger-inverted" href="">Rejected</a>
                        <?php
                        } ?>
                  </td>
                            </tr>
                             <?php 
                              }
                            }
                            else
                            {
                           ?>
                           <td >
                           <p>Not Found</p>
                           </td>
                          <?php                      
                            }       
                           ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <!--END - Recent Ticket Comments-->
                </div>
              </div> 

            </div>
          </div>

          <!--------------------
          END -  - main content
          -------------------->
        
<?php 
include('footer.php'); 
  ?>
 