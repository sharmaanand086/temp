<?php
 session_start();
  
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');
   $coachid = $_GET['id'];
  $sql="SELECT DISTINCT email,name,mobile FROM `intersubmitquestion` where coachid='$coachid'";
  $rs = mysqli_query($conn,$sql); 
  ?>  
  
 
          <!--------------------
          start - main content
          -------------------->
          <div class="content-i">
            <div class="content-box">
              <div class="row">
                <div class="col-sm-12">
                  <div class="element-wrapper">
                    <div class="element-actions">
                      <form class="form-inline justify-content-sm-end">
                        <select class="form-control form-control-sm">
                          <option value="Pending">
                            Today
                          </option>
                          <option value="Active">
                            Last Week 
                          </option>
                          <option value="Cancelled">
                            Last 30 Days
                          </option>
                        </select>
                      </form>
                    </div>
                    <h6 class="element-header">
                     Total Leads
                    </h6>
                    <div class="element-content">
                      <div class="row" style="display: none;">
                        <div class="element-box">    
                          <div class="form-desc">
                          <?php 
                    if(isset($_GET['msg'])){
                  ?> <div class="alert alert-success"> <?php echo $_GET['msg']; ?></div> 
                <?php } ?>
                <?php 
                    if(isset($_GET['msg1'])){
                  ?> <div class="alert alert-danger"> <?php echo $_GET['msg1']; ?></div> 
                <?php } ?>
                          </div>
                          <form class="form-inline"  action="insert_c_avilbty.php"  method = "POST">
                            <input type="hidden" name="coach_id" value="<?php echo $_SESSION['coach_id']; ?>">
                            <label class="sr-only">Date</label>
                           <input class="single-daterange form-control"  name="date" type="text" value="">
                            <label class="sr-only">Time From</label>
                            <input class="form-control mb-2 mr-sm-2 mb-sm-0 timepicker timepicker-with-dropdown text-center form-control"   type="text" name="timeform" >
                            <label class="sr-only"> Time To</label>
                            <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                               
                              <input class="form-control timepicker timepicker-with-dropdown text-center form-control" name="timeto" >
                            </div>
                            <button class="btn btn-primary" type="submit"> Submit</button>
                          </form>
                       </div>
                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="element-box">
                  
                  <div class="table-responsive">
                        <table class="table table-striped"><thead>
                          <tr><th>Sr No.</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                           

                          </tr>

                        </thead><tfoot>
                           <tr>
                            <th>Sr No.</th>
                           <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            
                          </tr>

                          </tfoot>
                          <tbody>
                            <?php  
                             if(mysqli_num_rows($rs)>0){
                             $a = 1;
                            while($row = $rs->fetch_assoc()) {
                           ?>

                            <tr>
                              <td><?php echo $a++ ?></td>
                              <td><?php echo $row["name"]; ?></td>
                              <td><?php echo $row["mobile"]; ?></td>
                             <td><?php echo $row["email"]; ?></td>
                              
                            </tr>
                          <?php
                          }}
                          else
                          {
                       ?>
                    <td >
                     <p>Not Found</p>
                     </td>
                      <?php                      
                      }        
                      ?>
                              </tbody>
                            </table>
                  </div>
                </div>
              
                
              </div>
              
          </div>
        <?php 
include('footer.php'); 
?>