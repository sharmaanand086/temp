<?php
 session_start();
  
$username1=  $_SESSION["username"];
 $name = explode("@", $username1);
 $username =$name[0];
include('connection.php');
include('header.php');
include('topnav.php');   
   $coachid = $_GET['id'];
  $sql="SELECT DISTINCT email,name,phone,session_date,session_time FROM `interclient_registrations` where coach_id='$coachid'";
  $rs = mysqli_query($conn,$sql);   
  ?>
          <!--------------------
          start - main content
          -------------------->
<div class="content-i">
            <div class="content-box">
              <div class="row">
                <div class="col-sm-12">
                  <div class="element-wrapper">
                    <div class="element-actions">
                      <form class="form-inline justify-content-sm-end">
                        <select class="form-control form-control-sm">
                          <option value="Pending">
                            Today
                          </option>
                          <option value="Active">
                            Last Week 
                          </option>
                          <option value="Cancelled">
                            Last 30 Days
                          </option>
                        </select>
                      </form>
                    </div>
                    <h6 class="element-header">
                     Total Bookings
                    </h6>
                    <div class="element-content">
                      
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="element-box">
                  
                  <div class="table-responsive">
                        <table class="table table-striped"><thead>
                          <tr><th>Sr No.</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                             <th>Date</th>
                             <th>Time</th>
                           

                          </tr>

                        </thead><tfoot>
                           <tr>
                            <th>Sr No.</th>
                           <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Date</th>
                            <th>Time</th>
                            
                          </tr>

                          </tfoot>
                          <tbody>
                            <?php  
                             if(mysqli_num_rows($rs)>0){
                             $a = 1;
                            while($row = $rs->fetch_assoc()) {
                           ?>

                            <tr>
                              <td><?php echo $a++ ?></td>
                              <td><?php echo $row["name"]; ?></td>
                              <td><?php echo $row["phone"]; ?></td>
                             <td><?php echo $row["email"]; ?></td>
                              <td><?php echo $row["session_date"]; ?></td>
                              <td><?php echo $row["session_time"]; ?></td>
                            </tr>
                          <?php
                          }}
                          else
                          {
                       ?>
                    <td >
                     <p>Not Found</p>
                     </td>
                      <?php                      
                      }        
                      ?>
                              </tbody>
                            </table>
                  </div>
                </div>
              
                
               </div>
              
             </div>
</div>

          <!--------------------
          END -  - main content
          -------------------->
<?php 
include('footer.php'); 
?>

        