 <div class="all-wrapper with-side-panel  solid-bg-all">
    
       
      <?php include('sidebar.php');
      