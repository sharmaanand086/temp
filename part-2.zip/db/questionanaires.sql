-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2020 at 10:47 AM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `questionanaires`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'anand@arfeenkhan.com', '1234'),
(2, 'bhavesh@arfeenkhan.com', '1234'),
(3, 'janvi@arfeenkhan.com', 'janvi@123'),
(4, 'mazhar@arfeenkhan.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `clients_status`
--

CREATE TABLE `clients_status` (
  `id` int(11) NOT NULL,
  `name` varchar(222) NOT NULL,
  `client_id` int(100) NOT NULL,
  `coach_id` int(100) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `comment` longtext NOT NULL,
  `yes_no` int(111) NOT NULL DEFAULT '3' COMMENT 'yes=1, no=2, none=3',
  `updatedat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients_status`
--

INSERT INTO `clients_status` (`id`, `name`, `client_id`, `coach_id`, `email`, `phone`, `comment`, `yes_no`, `updatedat`) VALUES
(25, 'pradeep', 41, 2, 'pradeep@arfeenkhan.com', '9877452525', ' dfgdsgsdg  ', 3, 'February 12 2020, 12:41:32 PM'),
(26, 'prachi', 45, 2, 'prachi@arfeenkhan.com', '1234567890', '', 3, 'February 12 2020, 01:23:54 PM'),
(27, 'siddhi', 42, 2, 'siddhi@arfeenkhan.com', '9852364260', ' ', 3, 'February 12 2020, 01:25:25 PM'),
(28, 'vishal', 43, 2, 'vishal@arfeenkhan.com', '9876543210', '', 2, 'February 12 2020, 01:32:43 PM'),
(29, 'arnav', 44, 2, 'arnav@arfeenkhan.com', '9856423172', '', 1, 'February 12 2020, 01:32:32 PM');

-- --------------------------------------------------------

--
-- Table structure for table `coachAvailibility`
--

CREATE TABLE `coachAvailibility` (
  `id` int(11) NOT NULL,
  `coach_id` varchar(100) NOT NULL,
  `date` varchar(222) NOT NULL,
  `time` varchar(222) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `live_or_not` int(11) NOT NULL DEFAULT '0' COMMENT 'yes=1 ,no=2, none=0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `coaches`
--

CREATE TABLE `coaches` (
  `id` int(11) NOT NULL,
  `coach_id` int(222) NOT NULL,
  `name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `profile_img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coaches`
--

INSERT INTO `coaches` (`id`, `coach_id`, `name`, `email`, `phone`, `password`, `profile_img`) VALUES
(1, 15, 'Hiba Gulaid', 'hgulaid2018@gmail.com', '971506565675', 'coaches@123', 'Author__Placeholder.png'),
(2, 10, 'Viitthal Mane', 'vsmane@gmail.com', '971509604363', 'coaches@123', 'Author__Placeholder.png'),
(3, 3, 'Saeed Qadri', 'saeedqadri@hotmail.com', '971507878162', 'coaches@123', 'Author__Placeholder.png'),
(4, 4, 'Mushtaq Ahmed', 'mushtaq_jnj@hotmail.com', '971507630211', 'coaches@123', 'Author__Placeholder.png'),
(5, 5, 'Muzamil Jehanzieb', 'muzamiljnzb@gmail.com', '971555871428', 'coaches@123', 'Author__Placeholder.png'),
(6, 6, 'Meg Osa', 'meg.osa@gmail.com', 'null', 'coaches@123', 'Author__Placeholder.png'),
(7, 7, 'Mobin uz Zaman', 'zaman.mubin@yahoo.com', 'null', 'coaches@123', 'Author__Placeholder.png'),
(8, 8, 'ShafiqZee Ahmed', 'ctfshafiqzee@gmail.com', 'null', 'coaches@123', 'Author__Placeholder.png'),
(9, 9, 'mtahiliani', 'mtahiliani04@gmail.com', 'null', 'coaches@123', 'Author__Placeholder.png'),
(10, 2, 'bhavesh gurav', 'bhavesh@arfeenkhan.com', '971507630211', '123456', 'IMG_6765.JPG'),
(16, 8, 'mazhar', 'mazhar@arfeenkhan.com', '8794000541', 'coaches@123', ''),
(17, 8, 'mazhar', 'mazhar@arfeenkhan.com', '8794000541', 'coaches@123', '');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `coach_id` int(222) NOT NULL,
  `client_id` int(222) NOT NULL,
  `comments` text NOT NULL,
  `updatedat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dbquestion`
--

CREATE TABLE `dbquestion` (
  `id` int(11) NOT NULL,
  `coach_id` varchar(222) NOT NULL,
  `video_link` text NOT NULL,
  `beforetk_video_link` text NOT NULL,
  `title` text NOT NULL,
  `p_visitor` text NOT NULL,
  `p_regitration` text NOT NULL,
  `p_booking` text NOT NULL,
  `coach_email` varchar(222) NOT NULL,
  `coach_name` varchar(222) NOT NULL,
  `pixel_code_home` longtext NOT NULL,
  `pixel_code_thankyou` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbquestion`
--

INSERT INTO `dbquestion` (`id`, `coach_id`, `video_link`, `beforetk_video_link`, `title`, `p_visitor`, `p_regitration`, `p_booking`, `coach_email`, `coach_name`, `pixel_code_home`, `pixel_code_thankyou`) VALUES
(7, '2', 'https://player.vimeo.com/video/388213439', 'https://player.vimeo.com/video/388213439', 'Discover who you are & how you can create an incredible life, in just 3 steps!\r\nSTEP 1\r\nWatch this video to know who is Arfeen Khan, the mastermind\r\nbehind this process, and what you’re about to become part of!', 'tes', 'srsew', 'afddsf', 'bhavesh@arfeenkhan.com', 'Bhavesh', 'zc', 'ZCADSAD');

-- --------------------------------------------------------

--
-- Table structure for table `etr`
--

CREATE TABLE `etr` (
  `id` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Age` varchar(200) NOT NULL,
  `City` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `daterange` mediumtext NOT NULL,
  `yourp` longtext NOT NULL,
  `yourb` longtext NOT NULL,
  `yourm` longtext NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=none 1=approve 2=reject',
  `uploaded_files` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etr`
--

INSERT INTO `etr` (`id`, `Name`, `email`, `Phone`, `Age`, `City`, `password`, `daterange`, `yourp`, `yourb`, `yourm`, `status`, `uploaded_files`) VALUES
(2, 'Bhavesh Gurav', 'bhavesh@arfeenkhan.com', '9876543210', '32', 'Mumbai', '1234', ' Date: 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 17.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 19.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 16.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'utfhchc', 'jhvjhvj', 'jhvjhvjhv ', 1, 'Canada_Sudbury_Clarabelle-Employees-Underground-016.jpg,pro.jpg'),
(4, 'Satish Kataria', 'satish.kataria@gmail.com', '9967972553', '28-52', 'Mumbai', '5.5', ' Date: 15.02.2020 Time : 10:00:00 AM to 12:00:00 PM ', 'I have more than 20 years experience in corporate life - with last 10 years involved in working with', 'test', 'My mission is to help entrepreneurs to find & achieve building their own path - to strengthen them along the life journey and achieve success in business dreams that they are working towards. ', 0, 'IMG_20180605_154202.jpg,IMG_20200110_150215 (1).jpg,IMG_20200110_150617 (1).jpg,Satish_profile.jpg'),
(5, 'Ashish Pal', 'ashishpal2702@gmail.com', '9251644048', '15-35', 'Bangalore', '5.5', ' Date: 12.02.2020 Time : 18:00:00 PM to 22:00:00 PM ', 'Data Scientist , AI ML Mentor and Life Transformation Coach.  ', 'I am Data scientist and have worked with Companies like Accenture, Siemens and Philips. \r\nI have mentored more than 1000 working professionals in up skilling their career.  \r\n', 'I am on a mission to democratize AI and technology and help youngsters and working professionals in up scaling their potential and achieve bigger goals.   ', 0, 'f5bc15b4-ec30-49be-970d-9f17bda8e2f5.JPG'),
(6, 'Kelsey de Waal', 'kelsey@shapemydestiny.online', '+9148297025', '21-40', 'Bengaluru', '5.5', ' Date: 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 17.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 19.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 16.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'I am an Inner Excellence coach. I help people excel in life, personally and financially.', 'I come from the Netherlands. I have travelled around the world and am also an  meditation and yoga practitioner.', ' I am on a mission to impact the lives of a 100,000 women by 2022 by helping them realise their true self worth. \r\nAs a result, she would trust herself fully and feel safe and powerful from within. She would be able to see a world of personal, professional and financial possibilities, feel confident to take action and be fearless in creating a life of her dreams. ', 0, 'IMG_0786.jpg'),
(7, 'Kelsey de Waal', 'kelsey@shapemydestiny.online', '+9148297025', '21-40', 'Bengaluru', '5.5', ' Date: 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 17.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM  Date: 19.02.2020 Time : 19:00:00 PM to 20:30:00 PM  Date: 16.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'I am an Inner Excellence coach. I help people excel in life, personally and financially.', 'I come from the Netherlands. I have travelled around the world and am also an  meditation and yoga practitioner.', ' I am on a mission to impact the lives of a 100,000 women by 2022 by helping them realise their true self worth. \r\nAs a result, she would trust herself fully and feel safe and powerful from within. She would be able to see a world of personal, professional and financial possibilities, feel confident to take action and be fearless in creating a life of her dreams. ', 0, 'IMG_0786.jpg'),
(8, 'mazhar', 'mazhar@arfeenkhan.com', '8794000541', '12-25', 'Mumbai', '-12', ' Date: 06.02.2020 Time : 08:00:00 AM to 09:00:00 AM ', '', '', ' ', 1, ''),
(13, 'Ashish Pal', 'ashishpal2702@gmail.com', '9251644049', '15-35', 'Bangalore', '-12', ' Date: 15.02.2020 Time : 18:00:00 PM to 23:00:00 PM ', 'Data Scientist | AI ML Mentor | Life Transformation Coach', 'I am an technologist and career guide and have mentored more than 1000 working professionals and students in Artificial Intelligence. \r\nData Scientist and worked with some top companies of the world. ', 'I am on a mission to impact millions of students and working professionals in up scaling their potential and moving ahead in their career and life.  ', 0, 'f5bc15b4-ec30-49be-970d-9f17bda8e2f5.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `getPdf`
--

CREATE TABLE `getPdf` (
  `id` int(11) NOT NULL,
  `category` text NOT NULL,
  `c_Pdf` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getPdf`
--

INSERT INTO `getPdf` (`id`, `category`, `c_Pdf`) VALUES
(1, 'Contribution', 'contribution.pdf'),
(2, 'Growth', 'growth.pdf'),
(3, 'Love / Connection', 'love_and_connection.pdf'),
(4, 'Certainty', 'certainty.pdf'),
(5, 'Variety / Uncertainty ', 'uncertainty.pdf'),
(6, 'Significance', 'significance.pdf'),
(7, 'Certainty and Variety / Uncertainty', 'certainty_and_uncertainty.pdf'),
(8, 'Certainty and Significance', 'certainty_and_significance.pdf'),
(9, 'Certainty and Love / Connection', 'certainty_and_love.pdf'),
(10, 'Certainty and Growth', 'certainty_and_growth.pdf'),
(11, 'Certainty and Contribution', 'certainty_and_contribution.pdf'),
(12, ' Variety / Uncertainty and Significance', 'uncertainty_and_significance.pdf'),
(13, ' Variety / Uncertainty and Love / Connection', 'uncertainty_and_love.pdf'),
(14, ' Variety / Uncertainty and Growth', 'uncertainty_and_growth.pdf'),
(15, ' Variety / Uncertainty and Contribution', 'uncertainty_and_contribution.pdf'),
(16, 'Significance and Love / Connection', 'significance_and_love.pdf'),
(17, 'Significance and Growth', 'significance_and_growth.pdf'),
(18, 'Significance and Contribution', 'significance_and_contribution.pdf'),
(19, 'Love / Connection and Growth', 'love_and_growth.pdf'),
(20, 'Love / Connection and Contribution', 'love_and_contribution.pdf'),
(21, 'Growth and Contribution', 'growth_and_contribution.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `id_request` int(200) NOT NULL,
  `datetimeslot` longtext NOT NULL,
  `UpdateDate` mediumtext NOT NULL,
  `status_2` int(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `id_request`, `datetimeslot`, `UpdateDate`, `status_2`) VALUES
(1, 15, ' 02/09/2020  Time :  17:00:00 PM to 21:00:00 PM  ', 'February 07, 2020 10:21:44 AM', 2),
(2, 15, ' 02/09/2020  Time :  17:00:00 PM to 21:00:00 PM  ', 'February 07, 2020 10:22:26 AM', 2),
(3, 15, ' 02/10/2020  Time :  17:00:00 PM to 21:00:00 PM  ', 'February 07, 2020 10:22:28 AM', 2),
(4, 15, ' 02/11/2020  Time :  17:00:00 PM to 21:00:00 PM  ', 'February 07, 2020 11:19:05 AM', 2),
(5, 1, ' 18.02.2020 Time : 09:00:00 AM to 09:30:00 AM ', 'February 14, 2020 05:57:44 AM', 2),
(6, 1, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 08:05:13 AM', 2),
(7, 1, ' 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 08:05:18 AM', 2),
(8, 1, ' 06.02.2020 Time : 08:00:00 AM to 09:00:00 AM ', 'February 14, 2020 08:15:13 AM', 2),
(9, 8, ' 06.02.2020 Time : 08:00:00 AM to 09:00:00 AM ', 'February 14, 2020 09:28:09 AM', 2),
(10, 2, ' 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:34:53 AM', 2),
(11, 2, ' 19.02.2020 Time : 19:00:00 PM to 20:30:00 PM ', 'February 14, 2020 09:34:55 AM', 2),
(12, 2, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:35:08 AM', 2),
(13, 2, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:35:10 AM', 2),
(14, 2, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:35:12 AM', 2),
(15, 2, ' 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:35:14 AM', 2),
(16, 2, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:58:27 AM', 2),
(17, 2, ' 16.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:58:38 AM', 2),
(18, 2, ' 17.02.2020 Time : 19:00:00 PM to 20:30:00 PM ', 'February 14, 2020 09:58:39 AM', 2),
(19, 2, ' 19.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:58:40 AM', 2),
(20, 2, ' 19.02.2020 Time : 19:00:00 PM to 20:30:00 PM ', 'February 14, 2020 09:58:40 AM', 2),
(21, 2, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM ', 'February 14, 2020 09:58:41 AM', 2);

-- --------------------------------------------------------

--
-- Table structure for table `intercalander`
--

CREATE TABLE `intercalander` (
  `id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `dateid` int(11) NOT NULL,
  `apmtime` varchar(255) NOT NULL,
  `time` time NOT NULL,
  `endtime` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intercalander`
--

INSERT INTO `intercalander` (`id`, `coach_id`, `date`, `dateid`, `apmtime`, `time`, `endtime`) VALUES
(1, 2, '2020-01-28', 1, '08:00 am - 08:15 am', '08:00:00', '08:15:00'),
(4, 2, '2020-01-28', 1, '08:45 am - 09:00 am', '08:45:00', '09:00:00'),
(8, 2, '2020-01-30', 2, '08:15 am - 08:30 am', '08:15:00', '08:30:00'),
(9, 2, '2020-01-30', 2, '08:30 am - 08:45 am', '08:30:00', '08:45:00'),
(10, 2, '2020-01-30', 2, '08:45 am - 09:00 am', '08:45:00', '09:00:00'),
(11, 2, '2020-01-30', 2, '09:00 am - 09:15 am', '09:00:00', '09:15:00'),
(12, 2, '2020-01-30', 2, '09:15 am - 09:30 am', '09:15:00', '09:30:00'),
(13, 2, '2020-01-29', 3, '08:00 am - 08:15 am', '08:00:00', '08:15:00'),
(14, 2, '2020-01-29', 3, '08:15 am - 08:30 am', '08:15:00', '08:30:00'),
(15, 2, '2020-01-29', 3, '08:30 am - 08:45 am', '08:30:00', '08:45:00'),
(16, 2, '2020-01-29', 3, '08:45 am - 09:00 am', '08:45:00', '09:00:00'),
(17, 2, '2020-01-29', 3, '09:00 am - 09:15 am', '09:00:00', '09:15:00'),
(18, 2, '2020-01-29', 3, '09:15 am - 09:30 am', '09:15:00', '09:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `interclient_registrations`
--

CREATE TABLE `interclient_registrations` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `session_date` varchar(200) NOT NULL,
  `session_time` varchar(200) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `pdf` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interclient_registrations`
--

INSERT INTO `interclient_registrations` (`id`, `name`, `email`, `phone`, `session_date`, `session_time`, `coach_id`, `pdf`) VALUES
(41, 'pradeep', 'pradeep@arfeenkhan.com', '9877452525', '2020-01-30', '08:45 am - 09:00 am', 2, ' contribution.pdf,  love_and_connection.pdf,  certainty.pdf,  uncertainty.pdf,  significance.pdf,  certainty_and_uncertainty.pdf,  certainty_and_significance.pdf,  certainty_and_love.pdf,  certainty_and_contribution.pdf,  uncertainty_and_significance.pdf,  uncertainty_and_love.pdf,  uncertainty_and_contribution.pdf,  significance_and_love.pdf,  significance_and_contribution.pdf,  love_and_contribution.pdf, '),
(45, 'prachi', 'prachi@arfeenkhan.com', '1234567890', '2020-01-30', '08:15 am - 08:30 am', 2, ' growth.pdf,  love_and_connection.pdf,  love_and_growth.pdf, '),
(42, 'siddhi', 'siddhi@arfeenkhan.com', '9852364260', '2020-01-30', '09:15 am - 09:30 am', 2, ' contribution.pdf,  certainty.pdf,  certainty_and_contribution.pdf, '),
(43, 'vishal', 'vishal@arfeenkhan.com', '9876543210', '2020-01-29', '09:15 am - 09:30 am', 2, ' contribution.pdf,  growth.pdf,  love_and_connection.pdf,  certainty.pdf,  uncertainty.pdf,  growth_and_contribution.pdf,  love_and_contribution.pdf,  certainty_and_contribution.pdf,  uncertainty_and_contribution.pdf, '),
(44, 'arnav', 'arnav@arfeenkhan.com', '9856423172', '2020-01-30', '08:30 am - 08:45 am', 2, ' uncertainty.pdf,  contribution.pdf,  significance.pdf,  uncertainty_and_contribution.pdf,  uncertainty_and_significance.pdf, ');

-- --------------------------------------------------------

--
-- Table structure for table `interreg-client`
--

CREATE TABLE `interreg-client` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `tagnumber` int(11) NOT NULL,
  `coachid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `intersubmitquestion`
--

CREATE TABLE `intersubmitquestion` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `tagnumber` varchar(200) NOT NULL,
  `coachid` varchar(200) NOT NULL,
  `topneeds` text NOT NULL,
  `marks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intersubmitquestion`
--

INSERT INTO `intersubmitquestion` (`id`, `name`, `email`, `mobile`, `tagnumber`, `coachid`, `topneeds`, `marks`) VALUES
(45, 'pradeep', 'pradeep@arfeenkhan.com', '9877452525', '', '2', 'a:5:{i:0;s:19:" Contribution Mark ";i:1;s:24:" Love / Connection Mark ";i:2;s:16:" Certainty Mark ";i:3;s:28:" Variety / Uncertainty Mark ";i:4;s:19:" Significance Mark ";}', 'a:5:{i:0;i:70;i:1;i:70;i:2;i:70;i:3;i:70;i:4;i:70;}'),
(46, 'mazhar', 'mazhar@arfeenkhan.com', '9876543210', '', '2', 'a:4:{i:0;s:16:" Certainty Mark ";i:1;s:24:" Love / Connection Mark ";i:2;s:28:" Variety / Uncertainty Mark ";i:3;s:19:" Significance Mark ";}', 'a:4:{i:0;i:30;i:1;i:20;i:2;i:20;i:3;i:20;}'),
(47, 'siddhi', 'siddhi@arfeenkhan.com', '9852364260', '', '2', 'a:2:{i:0;s:19:" Contribution Mark ";i:1;s:16:" Certainty Mark ";}', 'a:2:{i:0;i:125;i:1;i:115;}'),
(48, 'vishal', 'vishal@arfeenkhan.com', '9876543210', '', '2', 'a:5:{i:0;s:19:" Contribution Mark ";i:1;s:13:" Growth Mark ";i:2;s:24:" Love / Connection Mark ";i:3;s:16:" Certainty Mark ";i:4;s:28:" Variety / Uncertainty Mark ";}', 'a:5:{i:0;i:35;i:1;i:25;i:2;i:25;i:3;i:25;i:4;i:25;}'),
(49, 'arnav', 'arnav@arfeenkhan.com', '9856423172', '', '2', 'a:3:{i:0;s:28:" Variety / Uncertainty Mark ";i:1;s:19:" Contribution Mark ";i:2;s:19:" Significance Mark ";}', 'a:3:{i:0;i:130;i:1;i:120;i:2;i:120;}'),
(50, 'prachi', 'prachi@arfeenkhan.com', '1234567890', '', '2', 'a:2:{i:0;s:13:" Growth Mark ";i:1;s:24:" Love / Connection Mark ";}', 'a:2:{i:0;i:25;i:1;i:25;}');

-- --------------------------------------------------------

--
-- Table structure for table `live-pause`
--

CREATE TABLE `live-pause` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '3' COMMENT '1=live 2=pause and 3 = none',
  `datetimeslot` longtext NOT NULL,
  `id_request` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `live-pause`
--

INSERT INTO `live-pause` (`id`, `status`, `datetimeslot`, `id_request`) VALUES
(114, 1, ' 17.02.2020 Time : 11:00:00 AM to 13:00:00 PM  ', '2');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaires_info`
--

CREATE TABLE `questionnaires_info` (
  `title` varchar(64) NOT NULL,
  `min_desc` text NOT NULL,
  `date` date NOT NULL,
  `questionnaire_id` int(11) NOT NULL,
  `per_page` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `minutes` int(11) NOT NULL,
  `seconds` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questionnaires_info`
--

INSERT INTO `questionnaires_info` (`title`, `min_desc`, `date`, `questionnaire_id`, `per_page`, `status`, `minutes`, `seconds`) VALUES
('test 2', 'ertgertgertgerg', '2015-02-09', 24, 3, 1, 0, 0),
('Q1', 'q1 q2 q3', '2015-02-09', 26, 3, 1, 0, 0),
('Discover Your Mindset Blueprint', 'Every\nstatement\nmust\nbe\ngraded\nas:\n“No,”\n“Partly,”\nor\n“Yes.”\nHonestly\ngrade\neach\nstatement:\n“Yes,”\nfor\n“yes,\nthis\nis\nreally\nme.”\n“Partly”\nfor\nthis\nis\npartly\nhow\nI\nam,”\nand\n“No”\nfor\n“This\nis\nprobably\nnot\nhow\nI\nam.”\n(If\nyou\ndon’t\nknow\nwhether\nit\napplies,\nit’s\nusually\nbest\nto\ncheck\n“no.”)', '2015-02-12', 27, 10, 0, 0, 0),
('Xxx', 'dsfsdfdf', '2015-02-24', 28, 5, 1, 0, 0),
('Test', 'sssssssssssss', '2015-02-24', 30, 5, 1, 0, 15),
(' Copy Test', 'sssssssssssss', '2015-02-24', 31, 5, 1, 0, 0),
(' Copy Call of Destiny', 'Every\nstatement\nmust\nbe\ngraded\nas:\n“No,”\n“Partly,”\nor\n“Yes.”\nHonestly\ngrade\neach\nstatement:\n“Yes,”\nfor\n“yes,\nthis\nis\nreally\nme.”\n“Partly”\nfor\nthis\nis\npartly\nhow\nI\nam,”\nand\n“No”\nfor\n“This\nis\nprobably\nnot\nhow\nI\nam.”\n(If\nyou\ndon’t\nknow\nwhether\nit\napplies,\nit’s\nusually\nbest\nto\ncheck\n“no.”)', '2015-03-18', 33, 10, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions_info`
--

CREATE TABLE `questions_info` (
  `question_id` int(11) NOT NULL,
  `questionnaire_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `date` date NOT NULL,
  `ordering` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions_info`
--

INSERT INTO `questions_info` (`question_id`, `questionnaire_id`, `question`, `date`, `ordering`, `category_id`) VALUES
(101, 24, 's3www44ddfd', '2015-02-09', 5, 0),
(102, 24, 's3444', '2015-02-09', 3, 0),
(103, 26, 's1', '2015-02-09', 0, 0),
(105, 26, 's3', '2015-02-09', 0, 0),
(106, 26, 's5', '2015-02-09', 0, 0),
(107, 24, 'test  1', '2015-02-11', 0, 0),
(110, 26, 's3', '2015-02-12', 0, 0),
(111, 26, 's3423423', '2015-02-12', 0, 0),
(112, 26, 's4', '2015-02-12', 0, 0),
(114, 27, 'People are impressed by me', '2015-02-12', 1, 6),
(115, 27, 'Feeling that I “belong” is important to me', '2015-02-12', 2, 3),
(116, 27, 'I need to feel grounded', '2015-02-12', 3, 4),
(117, 27, 'I don’t mind taking risks', '2015-02-12', 4, 5),
(118, 27, 'I don’t fear change', '2015-02-12', 5, 5),
(119, 27, 'A failure is not a failure if you keep trying', '2015-02-12', 6, 2),
(120, 27, 'I believe in giving back', '2015-02-12', 7, 1),
(121, 27, 'I’m good at taking care of people', '2015-02-12', 8, 3),
(122, 27, 'I often worry about what people are saying about me', '2015-02-12', 9, 6),
(123, 27, 'I like to have as much stability in my life as possible', '2015-02-12', 10, 4),
(124, 27, 'It’s important to contribute to your community', '2015-02-12', 11, 1),
(125, 27, 'I like to develop new ideas and projects', '2015-02-12', 12, 5),
(126, 27, 'I’m security conscious', '2015-02-12', 13, 4),
(127, 27, 'I like to be an example to others', '2015-02-12', 14, 1),
(128, 27, 'I’m competitive', '2015-02-12', 15, 6),
(129, 27, 'I hate the feeling of boredom', '2015-02-12', 16, 5),
(130, 27, 'I know how to make connections with people', '2015-02-12', 17, 3),
(131, 27, 'I constantly aspire to improve', '2015-02-12', 18, 2),
(132, 27, 'Danger is never exciting to me', '2015-02-12', 19, 4),
(133, 27, 'In most close relationships I’m usually the giver', '2015-02-12', 20, 3),
(134, 27, 'There is always something new to be learned', '2015-02-12', 21, 2),
(135, 27, 'I need to feel fulfilled', '2015-02-12', 22, 1),
(136, 27, 'I frequently evaluate myself', '2015-02-12', 23, 6),
(137, 27, 'I like for things to be predictable', '2015-02-12', 24, 4),
(138, 27, 'I am more loving than most people', '2015-02-12', 25, 3),
(139, 27, 'Recognition is very important to me', '2015-02-12', 26, 6),
(140, 27, 'I like the feeling of exertion', '2015-02-12', 27, 5),
(141, 27, 'I’m very careful of not over spending', '2015-02-12', 28, 4),
(142, 27, 'Education is important to me', '2015-02-12', 29, 2),
(143, 27, 'I’m a leader', '2015-02-12', 30, 1),
(144, 27, 'I’m always looking for new experiences', '2015-02-12', 31, 5),
(145, 27, 'I sometimes over extend myself in trying to help people', '2015-02-12', 32, 3),
(146, 27, 'My routines and habits are important to me', '2015-02-12', 33, 4),
(147, 27, 'I take pride in who I am', '2015-02-12', 34, 6),
(148, 27, 'I like how learning something new changes my perspective', '2015-02-12', 35, 2),
(149, 27, 'Sometimes the most important work is not what you’re being paid for', '2015-02-12', 36, 1),
(150, 27, 'I’m not an adventurous person', '2015-02-12', 37, 4),
(151, 27, 'No one would say that I’m selfish', '2015-02-12', 38, 3),
(152, 27, 'I tend to spend beyond my limits', '2015-02-12', 39, 5),
(153, 27, 'I like to feel important', '2015-02-12', 40, 6),
(154, 27, 'Every failure is a learning experience', '2015-02-12', 41, 2),
(155, 27, 'I like to learn in order to teach what I learn', '2015-02-12', 42, 1),
(156, 27, 'I seek unity in my relationship', '2015-02-12', 43, 3),
(157, 27, 'I like to make a difference', '2015-02-12', 44, 1),
(158, 27, 'I refrain from acting when I’m not sure about all the consequences of my actions', '2015-02-12', 45, 4),
(159, 27, 'I suffer when I feel blocked', '2015-02-12', 46, 2),
(160, 27, 'I enjoy suspense', '2015-02-12', 47, 5),
(161, 27, 'Prestige is very important to me', '2015-02-12', 48, 6),
(162, 27, 'I’m a romantic', '2015-02-12', 49, 3),
(163, 27, 'I’m constantly learning', '2015-02-12', 50, 2),
(164, 27, 'Giving is more important to me than receiving', '2015-02-12', 51, 3),
(165, 27, 'I like to be Number 1', '2015-02-12', 52, 6),
(166, 27, 'I hate taking risks of any kind', '2015-02-12', 53, 4),
(167, 27, 'I like to constantly develop myself', '2015-02-12', 54, 2),
(168, 27, 'I like to give my time and energy to good causes', '2015-02-12', 55, 1),
(169, 27, 'I like to be admired by others', '2015-02-12', 56, 6),
(170, 27, 'I’m proud of my ability to learn new things', '2015-02-12', 57, 2),
(171, 27, 'We are here to make this world a better place', '2015-02-12', 58, 1),
(172, 27, 'I like to grow and develop in different areas', '2015-02-12', 59, 2),
(173, 27, 'Personal relationships are the most important thing in my life', '2015-02-12', 60, 3),
(174, 27, 'Sometimes I can be intimidating', '2015-02-12', 61, 6),
(175, 27, 'I often look for new forms of entertainment', '2015-02-12', 62, 5),
(176, 27, 'I’m concerned about anything that might be risky', '2015-02-12', 63, 4),
(177, 27, 'Being fulfilled in your work is more important than being admired', '2015-02-12', 64, 1),
(178, 27, 'I strive to improve my skills', '2015-02-12', 65, 2),
(179, 27, 'I get close to people by being generous with money, time and energy', '2015-02-12', 66, 3),
(180, 27, 'I like to think carefully before I go into action', '2015-02-12', 67, 4),
(181, 27, 'Sometimes I like the thrill of experiencing fear', '2015-02-12', 68, 5),
(182, 27, 'I need to feel respected', '2015-02-12', 69, 6),
(183, 27, 'When we stop growing, we die', '2015-02-12', 70, 2),
(184, 27, 'The feeling of togetherness is important to me', '2015-02-12', 71, 3),
(185, 27, 'For life to make sense, you have to leave a mark in the world', '2015-02-12', 72, 1),
(186, 27, 'Feeling comfortable at all times is important to me', '2015-02-12', 73, 4),
(187, 27, 'I enjoy being involved in many different activities', '2015-02-12', 74, 5),
(188, 27, 'I’m always comparing myself to others in terms of success', '2015-02-12', 75, 6),
(189, 27, 'I need to have passion in my relationship', '2015-02-12', 76, 3),
(190, 27, 'If I’m not contributing to others, my life is meaningless', '2015-02-12', 77, 1),
(191, 27, 'When making a decision, I often think about what might be more enjoyable', '2015-02-12', 78, 5),
(192, 27, 'I can’t stand to feel stagnant', '2015-02-12', 79, 2),
(193, 27, 'I need to feel as safe as possible at all times', '2015-02-12', 80, 4),
(194, 27, 'If I commit to something, I worry that something better might come along', '2015-02-12', 81, 5),
(195, 27, 'I never want to be seen as a loser', '2015-02-12', 82, 6),
(196, 27, 'I don’t care about having much stability in my life', '2015-02-12', 83, 5),
(197, 27, 'I have a mission', '2015-02-12', 84, 1),
(198, 28, 's1', '2015-02-24', 1, 1),
(199, 28, 's2', '2015-02-24', 1, 2),
(200, 28, 's3', '2015-02-24', 1, 3),
(201, 28, 's1', '2015-02-24', 2, 1),
(202, 28, 's2', '2015-02-24', 2, 2),
(203, 28, 's3', '2015-02-24', 2, 3),
(204, 28, 's2', '2015-02-24', 3, 2),
(205, 28, 's3', '2015-02-24', 3, 4),
(206, 28, 's1', '2015-02-24', 4, 1),
(207, 28, 's2', '2015-02-24', 4, 2),
(208, 28, 's5', '2015-02-24', 4, 1),
(209, 28, 's6', '2015-02-24', 4, 1),
(210, 28, 's7', '2015-02-24', 4, 3),
(215, 30, 'g1', '2015-02-24', 1, 2),
(216, 30, 'l1', '2015-02-24', 1, 3),
(217, 30, 'l2', '2015-02-24', 1, 3),
(218, 31, 's1', '2015-02-24', 1, 0),
(219, 31, 's3', '2015-02-24', 1, 0),
(220, 31, 's322', '2015-02-24', 1, 0),
(305, 33, 'People are impressed by me', '2015-03-18', 1, 6),
(306, 33, 'Feeling that I “belong” is important to me', '2015-03-18', 2, 3),
(307, 33, 'I need to feel grounded', '2015-03-18', 3, 4),
(308, 33, 'I don’t mind taking risks', '2015-03-18', 4, 5),
(309, 33, 'I don’t fear change', '2015-03-18', 5, 5),
(310, 33, 'A failure is not a failure if you keep trying', '2015-03-18', 6, 2),
(311, 33, 'I believe in giving back', '2015-03-18', 7, 1),
(312, 33, 'I’m good at taking care of people', '2015-03-18', 8, 3),
(313, 33, 'I often worry about what people are saying about me', '2015-03-18', 9, 6),
(314, 33, 'I like to have as much stability in my life as possible', '2015-03-18', 10, 4),
(315, 33, 'It’s important to contribute to your community', '2015-03-18', 11, 1),
(316, 33, 'I like to develop new ideas and projects', '2015-03-18', 12, 5),
(317, 33, 'I’m security conscious', '2015-03-18', 13, 4),
(318, 33, 'I like to be an example to others', '2015-03-18', 14, 1),
(319, 33, 'I’m competitive', '2015-03-18', 15, 6),
(320, 33, 'I hate the feeling of boredom', '2015-03-18', 16, 5),
(321, 33, 'I know how to make connections with people', '2015-03-18', 17, 3),
(322, 33, 'I constantly aspire to improve', '2015-03-18', 18, 2),
(323, 33, 'Danger is never exciting to me', '2015-03-18', 19, 4),
(324, 33, 'In most close relationships I’m usually the giver', '2015-03-18', 20, 3),
(325, 33, 'There is always something new to be learned', '2015-03-18', 21, 2),
(326, 33, 'I need to feel fulfilled', '2015-03-18', 22, 1),
(327, 33, 'I frequently evaluate myself', '2015-03-18', 23, 6),
(328, 33, 'I like for things to be predictable', '2015-03-18', 24, 4),
(329, 33, 'I am more loving than most people', '2015-03-18', 25, 3),
(330, 33, 'Recognition is very important to me', '2015-03-18', 26, 6),
(331, 33, 'I like the feeling of exertion', '2015-03-18', 27, 5),
(332, 33, 'I’m very careful of not over spending', '2015-03-18', 28, 4),
(333, 33, 'Education is important to me', '2015-03-18', 29, 2),
(334, 33, 'I’m a leader', '2015-03-18', 30, 1),
(335, 33, 'I’m always looking for new experiences', '2015-03-18', 31, 5),
(336, 33, 'I sometimes over extend myself in trying to help people', '2015-03-18', 32, 3),
(337, 33, 'My routines and habits are important to me', '2015-03-18', 33, 4),
(338, 33, 'I take pride in who I am', '2015-03-18', 34, 6),
(339, 33, 'I like how learning something new changes my perspective', '2015-03-18', 35, 2),
(340, 33, 'Sometimes the most important work is not what you’re being paid for', '2015-03-18', 36, 1),
(341, 33, 'I’m not an adventurous person', '2015-03-18', 37, 4),
(342, 33, 'No one would say that I’m selfish', '2015-03-18', 38, 3),
(343, 33, 'I tend to spend beyond my limits', '2015-03-18', 39, 5),
(344, 33, 'I like to feel important', '2015-03-18', 40, 6),
(345, 33, 'Every failure is a learning experience', '2015-03-18', 41, 2),
(346, 33, 'I like to learn in order to teach what I learn', '2015-03-18', 42, 1),
(347, 33, 'I seek unity in my relationship', '2015-03-18', 43, 3),
(348, 33, 'I like to make a difference', '2015-03-18', 44, 1),
(349, 33, 'I refrain from acting when I’m not sure about all the consequences of my actions', '2015-03-18', 45, 4),
(350, 33, 'I suffer when I feel blocked', '2015-03-18', 46, 2),
(351, 33, 'I enjoy suspense', '2015-03-18', 47, 5),
(352, 33, 'Prestige is very important to me', '2015-03-18', 48, 6),
(353, 33, 'I’m a romantic', '2015-03-18', 49, 3),
(354, 33, 'I’m constantly learning', '2015-03-18', 50, 2),
(355, 33, 'Giving is more important to me than receiving', '2015-03-18', 51, 3),
(356, 33, 'I like to be Number 1', '2015-03-18', 52, 6),
(357, 33, 'I hate taking risks of any kind', '2015-03-18', 53, 4),
(358, 33, 'I like to constantly develop myself', '2015-03-18', 54, 2),
(359, 33, 'I like to give my time and energy to good causes', '2015-03-18', 55, 1),
(360, 33, 'I like to be admired by others', '2015-03-18', 56, 6),
(361, 33, 'I’m proud of my ability to learn new things', '2015-03-18', 57, 2),
(362, 33, 'We are here to make this world a better place', '2015-03-18', 58, 1),
(363, 33, 'I like to grow and develop in different areas', '2015-03-18', 59, 2),
(364, 33, 'Personal relationships are the most important thing in my life', '2015-03-18', 60, 3),
(365, 33, 'Sometimes I can be intimidating', '2015-03-18', 61, 6),
(366, 33, 'I often look for new forms of entertainment', '2015-03-18', 62, 5),
(367, 33, 'I’m concerned about anything that might be risky', '2015-03-18', 63, 4),
(368, 33, 'Being fulfilled in your work is more important than being admired', '2015-03-18', 64, 1),
(369, 33, 'I strive to improve my skills', '2015-03-18', 65, 2),
(370, 33, 'I get close to people by being generous with money, time and energy', '2015-03-18', 66, 3),
(371, 33, 'I like to think carefully before I go into action', '2015-03-18', 67, 4),
(372, 33, 'Sometimes I like the thrill of experiencing fear', '2015-03-18', 68, 5),
(373, 33, 'I need to feel respected', '2015-03-18', 69, 6),
(374, 33, 'When we stop growing, we die', '2015-03-18', 70, 2),
(375, 33, 'The feeling of togetherness is important to me', '2015-03-18', 71, 3),
(376, 33, 'For life to make sense, you have to leave a mark in the world', '2015-03-18', 72, 1),
(377, 33, 'Feeling comfortable at all times is important to me', '2015-03-18', 73, 4),
(378, 33, 'I enjoy being involved in many different activities', '2015-03-18', 74, 5),
(379, 33, 'I’m always comparing myself to others in terms of success', '2015-03-18', 75, 6),
(380, 33, 'I need to have passion in my relationship', '2015-03-18', 76, 3),
(381, 33, 'If I’m not contributing to others, my life is meaningless', '2015-03-18', 77, 1),
(382, 33, 'When making a decision, I often think about what might be more enjoyable', '2015-03-18', 78, 5),
(383, 33, 'I can’t stand to feel stagnant', '2015-03-18', 79, 2),
(384, 33, 'I need to feel as safe as possible at all times', '2015-03-18', 80, 4),
(385, 33, 'If I commit to something, I worry that something better might come along', '2015-03-18', 81, 5),
(386, 33, 'I never want to be seen as a loser', '2015-03-18', 82, 6),
(387, 33, 'I don’t care about having much stability in my life', '2015-03-18', 83, 5),
(388, 33, 'I have a mission', '2015-03-18', 84, 1),
(390, 30, 'c', '2015-03-30', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `question_option_info`
--

CREATE TABLE `question_option_info` (
  `option_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `text` text NOT NULL,
  `question_id` int(11) NOT NULL,
  `questionnaire_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_option_info`
--

INSERT INTO `question_option_info` (`option_id`, `value`, `text`, `question_id`, `questionnaire_id`) VALUES
(178, 1, 'edswedfesw', 0, 26),
(183, 2, 'asdasdas', 0, 26),
(184, 10, 'qq', 105, 0),
(185, 20, 'ee', 105, 0),
(199, 3, 'qq', 101, 0),
(200, 14, 'ee', 101, 0),
(202, 33, 'eeee', 107, 0),
(203, 88, 'dtfgf', 107, 0),
(205, 3, 'ww', 102, 0),
(206, 4, 'sdfcsdfdsf', 0, 24),
(207, 44, 'www', 0, 24),
(208, 22, 'ttt', 107, 0);

-- --------------------------------------------------------

--
-- Table structure for table `recentactivity`
--

CREATE TABLE `recentactivity` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `client_id` int(200) NOT NULL,
  `coach_id` int(200) NOT NULL,
  `activity_description` longtext NOT NULL,
  `updatedat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recentactivity`
--

INSERT INTO `recentactivity` (`id`, `name`, `email`, `phone`, `client_id`, `coach_id`, `activity_description`, `updatedat`) VALUES
(5, 'pradeep', 'pradeep@arfeenkhan.com', '9877452525', 41, 2, 'pradeep booked the time slot : date: 2020-01-30	Time : 08:45 am - 09:00 am', 'February 12 2020, 11:42:40 AM'),
(6, 'siddhi', 'siddhi@arfeenkhan.com', '9852364260', 42, 2, 'siddhi booked the time slot : date: 2020-01-30	Time : 09:15 am - 09:30 am', 'February 12 2020, 11:50:28 AM'),
(7, 'vishal', 'vishal@arfeenkhan.com', '9876543210', 43, 2, 'vishal booked the time slot : date: 2020-01-29	Time : 09:15 am - 09:30 am', 'February 12 2020, 11:54:46 AM'),
(8, 'arnav', 'arnav@arfeenkhan.com', '9856423172', 44, 2, 'arnav booked the time slot : date: 2020-01-30	Time : 08:30 am - 08:45 am', 'February 12 2020, 12:05:55 PM'),
(9, 'prachi', 'prachi@arfeenkhan.com', '1234567890', 45, 2, 'prachi booked the time slot : date: 2020-01-30	Time : 08:15 am - 08:30 am', 'February 12 2020, 12:06:35 PM');

-- --------------------------------------------------------

--
-- Table structure for table `results_userinfos`
--

CREATE TABLE `results_userinfos` (
  `userinfo_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `marks` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `questionnaire_id` int(11) NOT NULL,
  `mobile` varchar(64) NOT NULL,
  `cat_marks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `results_userinfos`
--

INSERT INTO `results_userinfos` (`userinfo_id`, `name`, `email`, `marks`, `date`, `questionnaire_id`, `mobile`, `cat_marks`) VALUES
(46, 'pradeep', 'pradeep@arfeenkhan.com', 415, 1581465600, 27, '9877452525', '1 :  Contribution :  70,2 :  Love / Connection :  70,3 :  Certainty :  70,4 :  Variety / Uncertainty :  70,5 :  Significance :  70,6 :  Growth :  65,'),
(47, 'mazhar', 'mazhar@arfeenkhan.com', 115, 1581465600, 27, '9876543210', '1 :  Certainty :  30,2 :  Love / Connection :  20,3 :  Variety / Uncertainty :  20,4 :  Significance :  20,5 :  Contribution :  15,6 :  Growth :  10,'),
(48, 'anand', 'anand@arfeenkhan.com', 635, 1581465600, 27, '9852364260', '1 :  Contribution :  125,2 :  Certainty :  115,3 :  Significance :  105,4 :  Growth :  100,5 :  Love / Connection :  95,6 :  Variety / Uncertainty :  95,'),
(49, 'mazhar', 'mazhar@arfeenkhan.com', 155, 1581465600, 27, '9876543210', '1 :  Contribution :  35,2 :  Growth :  25,3 :  Love / Connection :  25,4 :  Certainty :  25,5 :  Variety / Uncertainty :  25,6 :  Significance :  20,'),
(50, 'arnav', 'arnav@arfeenkhan.com', 660, 1581465600, 27, '9856423172', '<b>1 :  Variety / Uncertainty :  130</b>,<b>2 :  Contribution :  120</b>,<b>3 :  Significance :  120</b>,4 :  Love / Connection :  105,5 :  Certainty :  95,6 :  Growth :  90,'),
(51, 'mazhar', 'mazhar@arfeenkhan.com', 115, 1581465600, 27, '1234567890', '<b>1 :  Growth :  25</b>,<b>2 :  Love / Connection :  25</b>,3 :  Certainty :  20,4 :  Significance :  20,5 :  Contribution :  15,6 :  Variety / Uncertainty :  10,');

-- --------------------------------------------------------

--
-- Table structure for table `skip_intro`
--

CREATE TABLE `skip_intro` (
  `id` int(11) NOT NULL,
  `coach_id` int(100) NOT NULL,
  `email` varchar(222) NOT NULL,
  `status` int(100) NOT NULL COMMENT '1=actice 0=inactive',
  `updatedat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skip_intro`
--

INSERT INTO `skip_intro` (`id`, `coach_id`, `email`, `status`, `updatedat`) VALUES
(3, 2, 'bhavesh@arfeenkhan.com', 1, 'February 11, 2020 09:10:14 AM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_status`
--
ALTER TABLE `clients_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coachAvailibility`
--
ALTER TABLE `coachAvailibility`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coaches`
--
ALTER TABLE `coaches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dbquestion`
--
ALTER TABLE `dbquestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `etr`
--
ALTER TABLE `etr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `getPdf`
--
ALTER TABLE `getPdf`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intercalander`
--
ALTER TABLE `intercalander`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interclient_registrations`
--
ALTER TABLE `interclient_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interreg-client`
--
ALTER TABLE `interreg-client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intersubmitquestion`
--
ALTER TABLE `intersubmitquestion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `live-pause`
--
ALTER TABLE `live-pause`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionnaires_info`
--
ALTER TABLE `questionnaires_info`
  ADD PRIMARY KEY (`questionnaire_id`);

--
-- Indexes for table `questions_info`
--
ALTER TABLE `questions_info`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `question_option_info`
--
ALTER TABLE `question_option_info`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `recentactivity`
--
ALTER TABLE `recentactivity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results_userinfos`
--
ALTER TABLE `results_userinfos`
  ADD PRIMARY KEY (`userinfo_id`);

--
-- Indexes for table `skip_intro`
--
ALTER TABLE `skip_intro`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `clients_status`
--
ALTER TABLE `clients_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `coachAvailibility`
--
ALTER TABLE `coachAvailibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `coaches`
--
ALTER TABLE `coaches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dbquestion`
--
ALTER TABLE `dbquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `etr`
--
ALTER TABLE `etr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `getPdf`
--
ALTER TABLE `getPdf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `intercalander`
--
ALTER TABLE `intercalander`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `interclient_registrations`
--
ALTER TABLE `interclient_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `interreg-client`
--
ALTER TABLE `interreg-client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `intersubmitquestion`
--
ALTER TABLE `intersubmitquestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `live-pause`
--
ALTER TABLE `live-pause`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
--
-- AUTO_INCREMENT for table `questionnaires_info`
--
ALTER TABLE `questionnaires_info`
  MODIFY `questionnaire_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `questions_info`
--
ALTER TABLE `questions_info`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=391;
--
-- AUTO_INCREMENT for table `question_option_info`
--
ALTER TABLE `question_option_info`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;
--
-- AUTO_INCREMENT for table `recentactivity`
--
ALTER TABLE `recentactivity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `results_userinfos`
--
ALTER TABLE `results_userinfos`
  MODIFY `userinfo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `skip_intro`
--
ALTER TABLE `skip_intro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
