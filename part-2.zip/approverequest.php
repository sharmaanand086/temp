<?php
session_start();
include("class.phpmailer.php");
include('connection.php');
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   $id = $_GET['id'];
  $sql="UPDATE `etr` SET `status`='1' WHERE id='$id'";
 $rs = mysqli_query($conn,$sql);

 $sql1 = "SELECT * FROM `etr` WHERE id='$id'";  
$rs1 = mysqli_query($conn,$sql1); 

$row = $rs1->fetch_assoc(); 

$name = $row['Name'];
$email = $row['email'];
$Phone = $row['Phone'];
$password = 'coaches@123';

$insertsql = "INSERT INTO `coaches`(`coach_id`, `name`, `email`, `phone`, `password`, `profile_img`) VALUES ('$id','$name','$email','$Phone','$password','')";                
                    if($rs == true)
                     {
            mysqli_query($conn,$insertsql);

try{
                 $mail = new PHPMailer(true); // the true param means it will throw exceptions on     errors, which we need to catch

                $mail->IsSMTP(); // telling the class to use SMTP
                $mail->Host = 'mail.arfeenkhan.com';  // Specify main and backup server
                $mail->Port = '26';
                $mail->SMTPAuth = 'true';                               // Enable SMTP authentication
                $mail->Username = 'arfeenkhan@arfeenkhan.com';                            // SMTP username
                $mail->Password = 'rNX7zSKSCnev';                           // SMTP password
                $mail->SMTPSecure = 'SSL/TLS';
                $mail->SetFrom('Arfeenkhan@arfeenkhan.com', 'Arfeen Khan');
            
                $mail->AddAddress($email, $Name);
                $mail->AddAddress('support@arfeenkhan.com', '');
               // $mail->AddAddress($_POST['username']);
                
                
                $mail->Subject ="Thank you for all your essentials... ";

      $mail->Body= "
      <p style='font-size: 14px;letter-spacing: 0px;margin: 0;'>Hi ".$Name.",</p><br>

 <p style='font-size: 14px;letter-spacing: 1px;margin: 0;'>
Thank you for all the essentials you sent for your facebook campaign.<br>
We will start working on your campaign now and update you in the next 2 working days.</p><br>
<p style='font-size: 14px;margin: 0;'>
URL : http://arfeenkhan.net/coach/<br>
Username : ".$email."<br>
Password : ".$password."
</p><br>
 <p style='font-size: 14px;letter-spacing: 0px;margin: 0;'> 
Thanks & Regards,<br>
Team Arfeen Khan.
</p>
";
           
      
      $mail->IsHTML(true);
        
      if( $mail->Send() )
        {
           
          $thank_page = true;        
                         
        }           
        else
        {
          echo "Email sending failed";
          $thank_page = false;
        } 
        
       } catch (phpmailerException $e) {
          echo "Email sending failed";
                 echo $e->errorMessage(); //Pretty error messages from PHPMailer
                } catch (Exception $e) {
                  echo "Email sending failed";
                echo $e->getMessage(); //Boring error messages from anything else!
            }

                  ?>
 <script>window.location="home.php";</script>  
    <?php
} else {
    echo "Error while approving record";
}