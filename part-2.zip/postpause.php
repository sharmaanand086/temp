<?php 

session_start();
include('connection.php');
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   

$requestid  = $_POST['id'] ;
$datetime  = $_POST['datetime'] ; 
$status = '2';

$query = "SELECT * FROM `live-pause` WHERE `datetimeslot`='$datetime'  AND status='1' AND id_request = '$requestid'";
 $result = mysqli_query($conn,$query); 
 if(mysqli_num_rows($result) == 1){
  $sqldelete = "DELETE FROM `live-pause` WHERE `datetimeslot`='$datetime'  AND status='1' AND id_request = '$requestid'";
  $resdelete = mysqli_query($conn,$sqldelete); 
  
    $timestamp = time();  
   $times= (date("F d, Y h:i:s A", $timestamp));

    $sql="INSERT INTO `history`(`id_request`, `datetimeslot`, `UpdateDate`, `status_2`)VALUES ('$requestid','$datetime','$times','$status')";   
    mysqli_query($conn,$sql); 

     
                    if($resdelete == TRUE)
                     {
                      echo "1";
                         
                      }else{
                         echo "0";  
                      }
 }else{

 }


                      
                   