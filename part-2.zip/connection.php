<?php

$conn = mysqli_connect('localhost', 'root', 'mumbai@123', 'questionanaires');

?>