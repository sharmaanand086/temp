<?php
session_start();
include('connection.php');
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   $id = $_GET['id'];
  $sql="UPDATE `etr` SET `status`='2' WHERE id='$id'";
 $rs = mysqli_query($conn,$sql);                   
                    if($rs == true)
                     {
                  ?>
 <script>window.location="home.php";</script>  
    <?php
} else {
    echo "Error while Rejecting record";
}