  <div class="layout-w">
  	<!--------------------
        START - Mobile Menu
        -------------------->
        <div class="menu-mobile menu-activated-on-click color-scheme-dark">
          <div class="mm-logo-buttons-w">
            <a class="mm-logo" href="home.php"><img src="img/logo.png"><span>Admin</span></a>
            <div class="mm-buttons">
              <div class="content-panel-open">
                <div class="os-icon os-icon-grid-circles"></div>
              </div>
              <div class="mobile-menu-trigger">
                <div class="os-icon os-icon-hamburger-menu-1"></div>
              </div>
            </div>
          </div>
          <div class="menu-and-user">
            <div class="logged-user-w">
              <div class="avatar-w">
                <img alt="" src="img/avatar1.jpg">
              </div>
              <div class="logged-user-info-w">
                <div class="logged-user-name">
                    <?php echo ucfirst($username); ?>
                </div>
                <div class="logged-user-role">
                    Administrator
                </div>
              </div>
            </div>
            <!--------------------
            START - Mobile Menu List
            -------------------->
            <ul class="main-menu">
              <li class="has-sub-menu">
                <a href="home.php">
                  <div class="icon-w">
                    <div class="os-icon os-icon-layout"></div>
                  </div>
                  <span>Dashboard</span></a>
                
              </li>
              <li class="has-sub-menu">
                <a href="ncoachrequests.php">
                  <div class="icon-w">
                    <div class="os-icon os-icon-layout"></div>
                  </div>
                  <span>New Coach Requests</span></a>               
              </li>  
             </ul>                   
          </div>
        </div>
        <!--------------------
        END - Mobile Menu
        -------------------->
        <!--------------------
        START - Main Menu
        -------------------->
        <div class="menu-w color-scheme-light color-style-default menu-position-side menu-side-left menu-layout-compact sub-menu-style-over sub-menu-color-bright selected-menu-color-light menu-activated-on-hover">
         
               <div class="logged-user-w avatar-inline">
                <div class="logged-user-i">
                  <div class="avatar-w" style="border: 0px;border-radius: 0%;">
                    <img alt="" src="img/logo.png" style="border-radius: 0%;width: 50%;">
                  </div> 
                </div>
                </div>        
                    <h1 class="menu-page-header">
                      Page Header
                    </h1>
                      <ul class="main-menu">
                        <li class="sub-header">
                          <span>Layouts</span>
                        </li>
                        <li class="selected has-sub-menu">
                          <a href="home.php">
                            <div class="icon-w">
                              <div class="os-icon os-icon-layout"></div>
                            </div>
                            <span>Dashboard</span></a>            
                        </li>   
                         <li class="has-sub-menu">
                            <a href="ncoachrequests.php">
                              <div class="icon-w">
                                <div class="os-icon os-icon-layout"></div>
                              </div>
                              <span>New Coach Requests</span></a>               
                          </li>   
                      </ul>
         
        </div>
        <!--------------------
        END - Main Menu
        -------------------->
         <div class="content-w">
          <!--------------------
          START - Top Bar
          -------------------->
          <div class="top-bar color-scheme-light" >
           
            <div class="top-menu-controls">
              <div class="element-search autosuggest-search-activator">
                <input placeholder="Start typing to search..." type="text">
              </div>
              <!--------------------
              START - Messages Link in secondary top menu
              -------------------->
              <div class="messages-notifications os-dropdown-trigger os-dropdown-position-left">
                <i class="os-icon os-icon-mail-14"></i>
                <div class="new-messages-count">
                  <?php
                             $ttl_bkg="SELECT DISTINCT Name,Phone, email  FROM `etr` where status='0' OR status='1' OR status='2'";
                              $rstotalbkg = mysqli_query($conn,$ttl_bkg); 
                              $total_clientsbkg = mysqli_num_rows($rstotalbkg);
                             ?> 
                             <?php echo $total_clientsbkg; ?>
                </div>
                <div class="os-dropdown light message-list">
                  <ul>
                    <?php while ($row = $rstotalbkg->fetch_assoc()) {  
                      
                     ?>
                    <li>
                      <a href="ncoachrequests.php">                        
                        <div class="message-content">
                          <h6 class="message-from">
                           <?php echo $row['Name']; ?>
                          </h6>
                          <h6 class="message-title">
                             <?php echo $row['Phone']; ?>
                          </h6>
                        </div>
                      </a>
                    </li>
                  <?php } ?>
                    
                  </ul>
                </div>
              </div>
             
              <div class="logged-user-w">
                <div class="logged-user-i">
                  <div class="avatar-w">
                    <img alt="" src="img/profile/Author__Placeholder.png">
                  </div>
                  <div class="logged-user-menu color-style-bright">
                    <div class="logged-user-avatar-info">
                      <div class="avatar-w">
                        <img alt="" src="img/profile/Author__Placeholder.png">
                      </div>
                      <div class="logged-user-info-w">
                       <div class="logged-user-name">
                    <?php echo ucfirst($username); ?>
                </div>
                <div class="logged-user-role">
                    Administrator
                </div>
                      </div>
                    </div>
                    <div class="bg-icon">
                      <i class="os-icon os-icon-wallet-loaded"></i>
                    </div>
                    <ul>
                    <!-- 
                      <li>
                        <a href="users_profile.php"><i class="os-icon os-icon-user-male-circle2"></i><span>Profile Details</span></a>
                      </li> -->
                    
                      <li>
                        <a href="logout.php"><i class="os-icon os-icon-signs-11"></i><span>Logout</span></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <!--------------------
              END - User avatar and menu in secondary top menu
              -------------------->
            </div>
            <!--------------------
            END - Top Menu Controls
            -------------------->
          </div>
          <!--------------------
          END - Top Bar
          -------------------->
         
